# PATRON — BTC Pattern Recognition & Forecasting Model
## সম্পূর্ণ Model Development Plan | Version 1.0

**PATRON** হলো একটি specialized machine-learning model, যার কাজ BTC/USDT-এর closed candlestick history বিশ্লেষণ করে candle-pattern/context recognition এবং পরবর্তী ৬টি 15-minute candle-এর probabilistic forecast তৈরি করা।

> এটি শুধু গবেষণা ও decision-support model। লাভের নিশ্চয়তা দেয় না; live trading বা order execution এই প্রকল্পের scope-এর বাইরে।

## এই ZIP-এ কী আছে
- `docs/01_PROJECT_PLAN_BN.md` — সম্পূর্ণ project plan, লক্ষ্য, scope ও phase
- `docs/02_MODEL_SPEC.md` — architecture, layer, tensor shape, parameter ও training design
- `docs/03_DATA_FEATURES_LABELS.md` — data source, ১২টি feature, labels ও leakage rules
- `docs/04_INPUT_OUTPUT_CONTRACT.md` — exact input/output contract এবং JSON example
- `docs/05_TRAINING_EVALUATION.md` — training, validation, metrics, baselines ও go/no-go gate
- `docs/06_IMPLEMENTATION_ROADMAP.md` — milestone, deliverables, acceptance criteria
- `config/model_config.yaml` — initial tunable parameters
- `schemas/input.schema.json`, `schemas/output.schema.json` — machine-readable contract
- `examples/sample_input.json`, `examples/sample_output.json` — example payload
- `requirements.txt` — Python dependencies
- `PROJECT_STRUCTURE.txt` — proposed repository layout
- `DECISIONS_AND_ASSUMPTIONS.md` — fixed decisions বনাম experiment-এ যাচাই করতে হবে এমন assumptions

## গুরুত্বপূর্ণ scope
এই প্রথম release-এ থাকবে **শুধু PATRON ML model**:
- থাকবে: historical data pipeline, candle feature extraction, pattern recognition, forecasting heads, training, evaluation, inference API/CLI।
- থাকবে না: LLM/Ollama, news/sentiment, AI agent/tool calling, Telegram, dashboard, exchange order execution, automatic live trading।

## Quick summary
- Market: BTC/USDT
- Primary candle timeframe: 15 minutes
- Context window: 96 closed candles (24 hours)
- Forecast horizon: next 6 candles (90 minutes)
- Input tensor: `float32[96, 12]`
- Core network: 1D-CNN → Bi-LSTM → Self-Attention
- Heads: pattern tags (auxiliary), TP/SL/timeout probabilities, forward price-range quantiles, momentum class
- Training framework: PyTorch
- Data format: Parquet
- First target: reproducible offline model + honest out-of-sample report

## Start order
1. Finalize exchange/data source and download historical BTC/USDT 15m data.
2. Validate and store raw candles.
3. Implement the exact feature builder and label builder.
4. Add leakage tests and chronological splits.
5. Train simple baselines first.
6. Train PATRON neural model only after baseline dataset is ready.
7. Evaluate with walk-forward and cost-aware simulation.
