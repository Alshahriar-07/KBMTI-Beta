# PATRON — Agent Memory

> Machine-maintained build log. Updated after every completed step.
> Specification source: `Plan/` (ZIP contents, treated as immutable).

---

## 1. Current Status

| Phase | Scope | State |
|---|---|---|
| 0 | Project setup, config, logging, paths | ✅ complete |
| 1 | Data acquisition + validation | ✅ complete (full 5y) |
| 2 | Feature engineering + scaler + patterns | ✅ complete |
| 3 | Labels (barrier / range / momentum) | ✅ complete |
| 4 | Dataset, splits, baselines | ✅ complete |
| 5 | Neural model + losses | ✅ complete (272,618 params) |
| 6 | Training loop | ✅ complete (`patron_v2`, LR scheduler, best epoch 3 / val 1.4048) |
| 7 | Evaluation + calibration | ✅ complete (`reports/evaluation_report.{json,md}`) |
| 8 | Inference CLI | ✅ complete (schema-valid output verified on the final checkpoint) |
| 9 | Tests | ✅ 44 at v2 ship; 86 after the scale-up (§13.11); 120 after the runtime (§14.8) |
| U1–U10 | Scale-up: multi-venue data, patterns, advanced features, walk-forward, multiseed | ✅ complete (details in §13) |
| A1–A8 | Autonomous runtime: candle-by-candle service, forecast ledger, maturation, drift, retraining, champion/challenger | ✅ complete (details in §14; live promotion not exercised — see §14.10) |
| T1 | Training pipeline audit (read-only diagnostics, no training) | ✅ complete (§15; `reports/training_upgrade/training_audit.md`) |
| T2–T3 | Optimization + multi-task loss experiment design | ✅ designed (§15.4, `plan/ADVANCED_TRAINING_UPGRADE.md`); runs pending |
| T4–T12 | Hard examples, regimes, patterns, error intelligence, continual training, runner, evaluation, governance, integration | ⏳ designed only |
| R1 | Public testing release `v1.0.0-beta.1`: licence, CLI, health check, packaging, docs, CI, release build | ✅ complete (§16) |

Environment: Windows 11, Python 3.12, CPU-only (RX 580 has no usable CUDA stack),
`torch==2.4.1+cpu`. All commands use `./.venv/Scripts/python.exe`.

## 2. Completed Steps

- **P0.1** Created `.venv`, installed pinned deps (`requirements.txt`), `pip install -e . --no-deps`.
- **P0.2** Package skeleton `src/patron/{data,features,labels,datasets,models,training,evaluation,inference,utils}`.
- **P0.3** `config.py` — pydantic models validating 12 features, 5 momentum classes, 6-bar horizon, 3 quantiles; `load_config()`; `save_snapshot()`.
- **P0.4** `paths.py`, `logging_utils.py` (console + rotating file + JSONL experiment log), `utils/seed.py`, `utils/io.py` (atomic JSON, sha256, parquet).
- **P1.1** `data/downloader.py` — monthly `data.binance.vision` archives + REST `/api/v3/klines` for current month; per-month parquet cache; canonical OHLCV schema.
- **P1.2** `data/validate.py` — `validate_candles` / `clean_candles`, gap detection, OHLC sanity, duplicate removal, `DataQualityReport`.
- **P1.3** `data/htf.py` — `resample_closed()` (drops incomplete buckets) + `htf_trend_frame()`.
- **P1.4** `data/pipeline.py` — orchestrates download → validate → clean → HTF cross-check → manifest + quality report.
- **P1.5** Full 5-year download (61 monthly partitions × 3 timeframes) and validation.
- **P2.1** `features/indicators.py` — `true_range`, `atr_wilder`, `rsi_wilder`, `ema`.
- **P2.2** `features/builder.py` — the exact 12 features, all causal; `feature_matrix`, `save_feature_schema`.
- **P2.3** `features/patterns.py` — 12 rule-based pattern tags with documented geometry (`PatternThresholds`).
- **P2.4** `features/scaler.py` — `RobustFeatureScaler` (median/IQR, clip ±5), JSON persistence with feature-version/order validation, `load_from_dict`.
- **P3.1** `labels/barrier.py` — triple barrier, first touch wins, same-candle double touch → ambiguous & masked; `barrier_class_weights`.
- **P3.2** `labels/range_labels.py` — `[N,6,3]` relative H/L/C targets, flatten/unflatten helpers.
- **P3.3** `labels/momentum.py` — ATR%-normalised 6-bar return binned into 5 classes.
- **P3.4** `labels/builder.py` — one supervised table (features + patterns + all labels), `sample_valid` rule, dataset manifest stats.
- **P4.1** `datasets/splits.py` — chronological 70/15/15 with purge 6 + embargo 6; `walk_forward_folds`; date summaries.
- **P4.2** `datasets/windows.py` — gap-aware valid-window indexing, lazy `SequenceDataset`, `make_datasets`, `make_walk_forward_datasets`.
- **P4.3** `scripts/build_dataset.py` executed end-to-end: 176,591 rows → 175,163 valid windows; scaler fit on train windows only.
- **P4.4** `datasets/loader.py` — loads the parquet artifact once, rebuilds splits, exposes bundle + scaler.
- **P4.5** `evaluation/baselines.py` — majority class, last-value persistence (barrier & momentum), multinomial logistic regression; all fitted on train only.
- **P5.1** `models/patron_net.py` — Conv1D blocks → BiLSTM → multi-head self-attention → FFN → attention pooling; heads: pattern (12), barrier (3), quantile (6×3×3, cumulative softplus offsets so quantiles cannot cross), momentum (5). 272,618 trainable params (spec budget 200k–1M).
- **P5.2** `models/losses.py` — masked cross-entropy, pinball loss, masked BCE, weighted total loss.
- **P6.1** `training/trainer.py` — AdamW (lr 3e-4, wd 1e-4), batch 128, grad clip 1.0, early stopping patience 12, `best.pt`/`last.pt`, JSONL logs, class weights from train split, temperature-free validation.
- **P6.2** `scripts/train.py`; 1-epoch smoke run `smoke_20261114-191544` (val 1.4151).
- **P6.3** Full training run `patron_v1_20261114-192046` (16 epochs, early stop, best epoch 4, val 1.4054) — kept for comparison.
- **P6.4** Added `ReduceLROnPlateau` (factor 0.5, patience 3, min_lr 1e-5, monitored on validation loss) per the spec's scheduler requirement; per-epoch LR is logged (the LR actually used for that epoch, captured before `scheduler.step`). Retrained as `patron_v2_20261114-203859`: 15 epochs, early stop, best epoch 3 VAL 1.4048.
- **P7.1** `evaluation/metrics.py` — accuracy, macro-F1, per-class PRF, ECE, Brier, pinball.
- **P7.2** `evaluation/calibration.py` — temperature scaling fitted on validation only.
- **P7.3** `evaluation/evaluator.py` + `scripts/evaluate.py` — raw + calibrated metrics per split, baseline comparison, markdown/JSON report.
- **P8.1** `inference/pipeline.py` — input JSON Schema validation, 96-bar contiguity/closure checks, warm-up loading from the clean parquet, feature build, model forward, schema-conformant JSON, explicit `NO_OUTPUT` path.
- **P8.2** `scripts/predict.py` — CLI, `--checkpoint`/`--input`/`--warmup`/`--output`, validates the schema before writing.
- **P8.3** End-to-end inference verified on a real 96-bar window (`data/clean/BTCUSDT/latest_input.json`) with the smoke checkpoint: status OK, quantiles ordered, probabilities sum to 1, output accepted by `Plan/schemas/output.schema.json`.
- **P7.4** Added `balanced_accuracy` (`sklearn.metrics.balanced_accuracy_score`) to `classification_metrics` for every classification head, since the majority baseline is misleading on this imbalanced target. Also surfaced in `report_to_markdown` (barrier table + momentum bullets) and regenerated `reports/evaluation_report.md` from the JSON.
- **P7.5** Evaluation rerun on `experiments/patron_v2_*/best.pt`: `reports/evaluation_report.{json,md}` written; full baseline comparison included.
- **P9.1** pytest suite (44 tests) — data validation, feature causality, label horizon/leakage, window/split integrity, model shapes/param budget, losses, inference contract.

## 3. Current Step

All phases 0–9 are complete and verified end to end. Final verification after the last edits (LR scheduler + balanced accuracy): pytest 44 passed → train `patron_v2` → evaluate → predict smoke, all green.

## 4. Files Created

```
pyproject.toml, requirements.txt, README.md, .gitignore
config/model_config.yaml                     (spec config + additive `data:` block)
src/patron/__init__.py
src/patron/config.py  paths.py  logging_utils.py
src/patron/utils/{__init__,seed,io}.py
src/patron/data/{__init__,downloader,validate,htf,pipeline}.py
src/patron/features/{__init__,schema,indicators,builder,patterns,scaler}.py
src/patron/labels/{__init__,barrier,range_labels,momentum,builder}.py
src/patron/datasets/{__init__,splits,windows,loader}.py
src/patron/models/{__init__,patron_net,losses}.py
src/patron/training/{__init__,trainer}.py
src/patron/evaluation/{__init__,metrics,calibration,baselines,evaluator}.py
src/patron/inference/{__init__,pipeline}.py
scripts/{download_data,build_dataset,train,evaluate,predict}.py
tests/{conftest,test_data_validation,test_features_causality,test_labels,test_dataset,test_model_losses,test_inference}.py
plan/memory.md
```

## 5. Files Modified

- `src/patron/features/scaler.py` — added `load_from_dict` (used by inference to avoid a temp file).
- `src/patron/inference/pipeline.py` — fixed `SCHEMA_DIR` import and clean-parquet path (`CLEAN_DIR/symbol/15m.parquet`).
- `scripts/build_dataset.py` — `REPORT_DIR` import fix; `cfg.training.random_seed`.
- `src/patron/labels/momentum.py` — clipped future index (off-by-horizon IndexError at the tail).
- `src/patron/training/trainer.py` — added `ReduceLROnPlateau` (spec scheduler requirement), LR logged per epoch, scheduler string recorded in the JSONL `start` event.
- `src/patron/evaluation/metrics.py` — added `balanced_accuracy` to `classification_metrics`.
- `src/patron/evaluation/baselines.py` — `LogisticRegression(n_jobs=-1)` removed (no-op warning in sklearn 1.9); earlier `multi_class` kwarg removed (sklearn ≥1.5 rejects it).
- `scripts/evaluate.py` — unchanged CLI (`--checkpoint`, `--config`, `--dataset`, `--out`, `--no-baselines`).
- `src/patron/config.py` — added `timeframe` property.
- `src/patron/data/pipeline.py` — `resample_closed` now imported from `data.htf` (single implementation).
- `src/patron/data/htf.py` — vectorised threshold fix in `cross_check_htf`.

## 6. Commands Executed

```bash
python -m venv .venv && ./.venv/Scripts/pip install -r requirements.txt
./.venv/Scripts/python.exe -m pip install -e . --no-deps
./.venv/Scripts/python.exe scripts/download_data.py --start 2021-11-01
./.venv/Scripts/python.exe scripts/build_dataset.py
./.venv/Scripts/python.exe scripts/train.py --epochs 1 --run-name smoke   # smoke
./.venv/Scripts/python.exe scripts/train.py --run-name patron_v1          # first full run (constant LR)
./.venv/Scripts/python.exe scripts/train.py --run-name patron_v2          # final run (ReduceLROnPlateau)
./.venv/Scripts/python.exe scripts/evaluate.py --checkpoint experiments/patron_v2_*/best.pt
./.venv/Scripts/python.exe scripts/predict.py --input data/clean/BTCUSDT/latest_input.json \
    --checkpoint experiments/patron_v2_*/best.pt --output reports/predictions/latest.json
./.venv/Scripts/python.exe -m pytest -q
```

## 7. Tests and Results

- `download_data.py` (2021-11-01 → 2026-11-14): 15m 176,591 / 1h 44,148 / 4h 11,037 rows; 1 gap of 5 bars on 15m (2023-03), 0 rejects, 0 duplicate rows.
- HTF cross-check: 1h compared 44,147 → 0 mismatches; 4h compared 11,036 → 0 mismatches.
- `build_dataset.py`: 176,591 rows, 175,354 trainable, 175,163 windows; 318 warm-up rejects, 108 gap-spanning, 1,237 label-tail.
- Barrier: TP-first 45,575 / SL-first 80,767 / timeout 49,221 / ambiguous 3,273 (masked).
- Momentum: 39,802 / 30,113 / 38,481 / 28,984 / 39,192.
- **pytest: 44 passed** (causality, leakage, horizon, gap windows, purge/embargo, shapes, 272,618-param budget, quantile monotonicity, masked losses, inference schema + `NO_OUTPUT`).
- Smoke training (1 epoch): train 1.4589 / val 1.4151, barrier acc 0.360, momentum acc 0.255, 256 s.
- **Training `patron_v2`** (final): 15 epochs, 244–281 s/epoch, best epoch 3 val 1.4048, early stop at 15 (`logs/train_v2.out`). LR dropped 3e-4 → 1.5e-4 at epoch 6 and lower thereafter; val loss then worsened monotonically (train 1.246), i.e. overfitting, not a LR problem.
- **Evaluation on `patron_v2` test split (26,269 windows, 2026-01-30 → 2026-10-30), temperature 1.0165:**

  | Metric | value |
  |---|---|
  | Barrier accuracy | 0.3813 |
  | Barrier balanced accuracy | 0.4093 |
  | Barrier macro-F1 | 0.3826 |
  | Barrier ROC-AUC (OvR) | 0.5937 |
  | Barrier log loss / ECE | 1.0592 / 0.0276 |
  | Momentum accuracy / balanced acc | 0.2382 / 0.2370 |
  | Momentum macro-F1 / log loss / ECE | 0.2244 / 1.5939 / 0.0089 |
  | Range pinball (mean) | 0.000974 (0 crossings) |
  | Pattern mAP | 0.0864 |

- Baselines (test): majority barrier 0.4692 acc / 0.2129 F1; majority momentum 0.2077 / 0.0688; logistic barrier 0.4708; logistic momentum 0.2578; persistence-flat range close MAE 0.00254.
- v1 → v2: barrier accuracy 0.3666 → 0.3813, macro-F1 0.3673 → 0.3826, ECE 0.048 → 0.028; momentum 0.2518 → 0.2382 (slightly worse); pinball unchanged. Overall a small net improvement, dominated by run-to-run variance.
- **Final pytest: 44 passed in 2.85 s** after the scheduler / balanced-accuracy / baseline edits (`py_compile` clean on all three edited modules).
- Inference smoke on the final checkpoint: `data/clean/BTCUSDT/latest_input.json` → status `OK`, schema-validated, as_of 2026-11-14T13:00Z, barrier 0.432/0.441/0.126.
- Bundled `Plan/examples/sample_input.json` repeats only 4 timestamps (illustrative placeholder) — correctly rejected by the validator; not used as a test fixture.

## 8. Errors and Fixes

| Error | Cause | Fix |
|---|---|---|
| `OSError WinError 126 shm.dll` on `import torch` | torch 2.15.0+cpu vs MSVC runtime 14.29 | pinned `torch==2.4.1` (CPU) |
| `IndexError` in `momentum_labels` | unclipped `arange(n)+horizon` | `np.minimum(..., n-1)` before masking |
| `AttributeError: 'PatronConfig' object has no attribute 'timeframe'` | missing property | added property |
| `AttributeError: ... 'seed'` | config field is `random_seed` | corrected call site |
| `cross_check_htf` threshold on Series | `max(float, Series)` ambiguous | `np.maximum` |
| Duplicate `resample_closed` | copy-paste | pipeline imports from `data.htf` |
| Inference `ImportError` / missing clean path | stale `data` helper import | `SCHEMA_DIR`, `CLEAN_DIR/symbol_slug/15m.parquet` |
| `AttributeError: RobustFeatureScaler.load_from_dict` | method did not exist | added classmethod, `load()` delegates to it |
| `evaluate.py` > 600 s | CPU shared with the running training job | run after training, longer timeout |
| `TypeError: LogisticRegression.__init__() got an unexpected keyword argument 'multi_class'` | sklearn 1.9 removed the kwarg (multinomial is now the only behaviour) | dropped the kwarg; `roc_auc_score(multi_class="ovr")` still valid |
| `FutureWarning: 'n_jobs' has no effect` | `n_jobs=-1` passed to `LogisticRegression` | removed `n_jobs` from both baseline fits |
| `evaluate.py: error: --checkpoint is required` | ran with `--run-dir` | use `--checkpoint experiments/<run>/best.pt` |
| pytest initial 5 failures | wrong validator signature, wrong expected gap window range (`[t-95, t+6]` not `[t-101, t+6]`), symmetric quantile total pinball, 95-candle schema `minItems` shadowing the gap check | fixed the tests (validator behaviour was correct) |

## 9. Technical Decisions

- **D-01 Data source.** Binance spot: monthly `data.binance.vision` archives + REST for the open month. No API key, reproducible, matches the spot BTC/USDT scope.
- **D-02 Additive config block.** `data:` added to `model_config.yaml` for download settings only; no model/feature/label semantics touched.
- **D-03 No `ta`/`mlflow`.** Indicators implemented directly (auditable, no version drift); JSONL experiment logging replaces MLflow on a CPU-only 16 GB host.
- **D-04 HTF alignment.** 1h/4h candles resampled from 15m, aligned on HTF **close** via `merge_asof`; incomplete buckets dropped, so a partial candle can never leak.
- **D-05 Features.** Ratios/differences only — no absolute BTC prices. All rolling windows look backwards only.
- **D-06 `feature_valid`.** Rows with any non-finite feature are flagged, never filled. Windows containing an invalid row or a gap are dropped.
- **D-07 Scaler.** `RobustFeatureScaler` (median/IQR, clip ±5) fit on the training partition only; persisted with feature version + order and validated on load.
- **D-08 Ambiguous barriers.** Same-candle TP+SL touch masked out of the primary barrier loss; `conservative_ambiguous=True` available for sensitivity.
- **D-09 Target space.** Range targets relative to the window's last close (`future/close_t - 1`).
- **D-10 Splits.** Chronological 70/15/15 with 6-bar purge + 6-bar embargo; test split touched once.
- **D-11 Quantile head.** Predicted as median + cumulative softplus offsets, so q10 ≤ q50 ≤ q90 by construction (no post-hoc sorting that would hide a broken head).
- **D-12 Inference warm-up.** `WARMUP_BARS=384` prior 15m candles from the clean parquet are required for ATR/EMA/HTF warm-up; without them the API returns `NO_OUTPUT` rather than silently cold-starting features.
- **D-13 Test design.** Synthetic deterministic candles (no dependence on downloaded data), so tests are fast and reproducible; the real artifact is checked separately by the evaluation and inference smoke runs.
- **D-14 LR scheduler.** The spec requires "ReduceLROnPlateau or cosine with warmup; choose one and log it". `ReduceLROnPlateau(mode="min", factor=0.5, patience=3, min_lr=1e-5)` is used: it reacts to the actual validation loss instead of a fixed schedule, and the JSONL `start` event plus every epoch record the LR. Documented because the first run (`patron_v1`) shipped without one.
- **D-15 Class weights vs accuracy.** Class weights are computed from the training split and kept, so the barrier head over-predicts `tp_first` (51% predicted vs 26% base rate) and plain accuracy sits below the majority baseline. Accuracy is therefore reported next to **balanced accuracy** and ROC-AUC; removing the weights raises accuracy and destroys the little signal there is, so the weights stay.
- **D-16 Honest reporting.** Results are reported as-is, including the momentum head being near the uniform prior (1.594 vs 1.609) and barrier accuracy below majority. No post-hoc threshold tuning on the test split.

## 10. Configuration Changes

- Added `data:` section (source, base URLs, start `2021-11-01`, timeframes 15m/1h/4h, pause 0.15 s).
- Pinned `torch==2.4.1` in `requirements.txt` with the Windows DLL rationale.
- Removed `ta` and `mlflow` from `requirements.txt`.
- No changes to architecture, dims, features, horizon, hyperparameters, loss weights or splits.

## 11. Pending Tasks

None — phases 0–9, the scale-up U1–U10 and the runtime A1–A8 are implemented and verified
(§13.11, §14.8). Explicitly out of scope / not claimed: per-fold retraining walk-forward
(~1 h/fold on this CPU), a completed live candidate retrain, training on dataset 2.0.0, and
any live/telemetry or trading work.

## 12. Next Step

Run `scripts/patron_service.py serve` for several days so the evidence trigger reaches its
288 matured horizons, then inspect the first real candidate job end to end. Beyond that,
the honest next experiment is retraining on dataset 2.0.0
with its own untouched holdout, or wiring cross-venue basis features as *inputs* (they were
only collected, never fed to a model).

## 13. Upgrade — dataset 2.0.0 (multi-venue, patterns, advanced evaluation)

Roadmap: `plan/UPGRADE_ROADMAP.md`. Baseline model and dataset 1.0.0 are untouched;
the shipped checkpoint is still `experiments/patron_v2_20261114-203859/best.pt`.

### 13.1 Venue registry and adapters (U1)

- `data/markets.py` — declarative venues (Binance, Bybit, OKX, Coinbase, Kraken, Bitget):
  per-venue symbol maps (Kraken `XBTUSD`, OKX `BTC-USDT`, Coinbase `BTC-USD`), interval
  maps, rate limits, quote currency and licence notes. Unmapped assets fail loudly.
- `data/venues.py` — canonicalising REST adapters. Verified live against all six venues.
- `data/quality.py` — venue-aware validation (OHLC, closed candles, duplicates, gaps,
  coverage, volume sanity, robust-z return outliers), sha256 `frame_checksum`.
- `data/collect.py` — resumable `exchange/market/asset/timeframe` parquet partitions with
  sidecar metadata (request window, checksum, coverage, full quality report).
- Tests: `tests/test_exchange_data.py` (symbol maps, dedupe, defects, checksum, alignment).

### 13.2 Collection results (U2/U3)

BTC 15m, 2023-11-01 → 2026-11-14 (all six venues, `data/manifests/btc_multivenue_15m*.json`):

| Venue | Quote | Rows | Coverage | Gaps | Outliers | Note |
|---|---|---|---|---|---|---|
| binance | USDT | 106,528 | 1.000 | 0 | 84 | full window |
| bybit | USDT | 106,529 | 1.000 | 0 | 87 | full window (backward paging fix) |
| okx | USDT | 106,528 | 1.000 | 0 | 81 | full window |
| coinbase | USD | 106,472 | 0.9995 | 5 (57 bars) | 79 | USD-quoted |
| kraken | USD | 720 | 1.000 | 0 | 1 | API caps 720 bars (~7.5 days) |
| bitget | USDT | 959 | 1.000 | 0 | 1 | ~10 days of 15m history |

- Cross-venue panel written to `data/processed/unified/panel_BTC_15m.parquet`
  (outer join, per-venue columns, no blind merging); report `reports/data_expansion_report.md`.
- 10 auxiliary assets collected on Binance + Bybit 15m 2023-11 → present (manifest
  `assets_15m_binance_bybit.json`); they are context only, never relabelled to BTC targets.

### 13.3 Multi-timeframe (U4)

- `data/timeframes.py`: 1m/5m/15m/30m/1h/4h/1d, `resample_ohlcv` drops incomplete buckets and
  verifies the bucket's last source close, `align_htf_causal` merges on HTF *close* with
  `merge_asof(direction="backward")`.
- Tests: `tests/test_multitimeframe.py` (manual aggregation, dropped partial bucket,
  no-lookahead, HTF alignment, 1d).

### 13.4 Advanced features (U5) — negative ablation result

- `features/advanced.py`: 34 features in 5 groups (price, candle, volume, trend, structure)
  with a formula per feature in `FEATURE_FORMULAS` and a causality test.
- Ablation (`scripts/run_feature_ablation.py`, sklearn HistGradientBoosting proxy on the
  last bar of each window, train/validation only):

| Config | Features | Balanced acc | Log loss |
|---|---|---|---|
| v1_12 | 12 | 0.3123 | **1.0457** |
| advanced_all | 34 | 0.3641 | 1.0507 |
| v1_plus_advanced | 46 | 0.3644 | 1.0493 |
| advanced_structure | 6 | 0.3444 | 1.0572 |
| advanced_trend | 9 | 0.3539 | 1.0581 |

- **No advanced configuration beat the 12 original features**; documented as a negative
  result in `reports/feature_ablation_report.md`. Not adopted into the shipped model.
- LightGBM 4.7.0 crashes natively on this host (numpy 2.5.4), so the boosting proxy is
  sklearn's `HistGradientBoostingClassifier`; recorded rather than hidden.

### 13.5 Pattern registry (U6)

- `patterns/detectors.py` (causal context + primitives), `patterns/registry.py`
  (103 candlestick patterns: 21 single, 30 double, 35 triple, 15 four-to-eight candle,
  2 aggregate; 46 bullish / 48 bearish / 9 neutral), `patterns/structures.py`
  (16 chart structures, separate category).
- Every entry carries name, direction, candle count, formula, executed conditions, context
  requirement, base confidence, reference and a detector.
- Tests: `tests/test_pattern_registry.py` (count, documentation, shapes, causality by
  truncation, structures, dead-detector policy).

### 13.6 Pattern dataset (U7)

- `patterns/dataset.py` → 935,261 occurrences across 94 patterns on Binance BTC 15m
  (2021-11 → 2026-11), outcomes at 1/2/3/6/12/24 candles (raw + ATR-normalised, max
  up/down), regime labels from expanding (causal) statistics.
- `reports/pattern_research_report.md`: occurrence-weighted 6-candle hit rate 0.492;
  45 patterns have |z| > 1.96 before any multiple-testing correction — treated as
  hypothesis generation, not edge.
- Artifacts in `data/processed/patterns/v1/` + `data/manifests/pattern_dataset_v1.json`.

### 13.7 Walk-forward (U9) and the split-date bug

- `scripts/run_walk_forward.py` evaluates the fixed v2 checkpoint on 4 rolling blocks of the
  untouched test period plus trend/volatility regime slices.
- Result: barrier accuracy 0.3648 / 0.3720 / 0.3856 / 0.4029 across blocks; balanced accuracy
  0.4005–0.4280; momentum 0.231–0.244; pinball 0.00089–0.00112.
- **Bug found and fixed:** `split_dates` treated sample indices as bar indices, so reports
  showed the test split ending 2026-10-30 instead of 2026-11-14. It now takes an optional
  `positions` array; the evaluator passes it; regression test
  `test_split_dates_map_positions_to_bar_timestamps` added. Metrics were unaffected (they
  are computed from predictions), only the reported dates were wrong.
- Limitation: true fold-by-fold *retraining* is implemented (`walk_forward_folds`) but not run
  — it costs ~1 h per fold on this CPU.

### 13.8 Multi-seed (U8)

- `scripts/train_multiseed.py` — 3 seeds (42/7/2026), **4 epochs, stride 4**, batch 128,
  checkpoint selection on validation only; `trainer.train(seed=...)` override added and the
  seed recorded in the JSONL `start` event.
- Results (`reports/multiseed_report.md`): best val loss 1.4122 ± 0.0007, val barrier
  accuracy 0.3180 ± 0.0039, val momentum accuracy 0.2437 ± 0.0029.
- Budget was cut from 6 epochs/stride 2 to 4 epochs/stride 4 because the host kills
  background jobs when the session closes and the tool caps foreground runs at 10 min
  (~4.5 min per seed at this budget). All three seeds share the same budget, so the
  dispersion is comparable; it is still not a full training protocol.

### 13.9 Upgrade errors and fixes

| Error | Cause | Fix |
|---|---|---|
| Bybit returned 999 bars for a 3-year request | v5 kline ignores `start` when the window exceeds `limit` | page backwards from `end` |
| Bitget returned 0 rows for 3 years | v2 spot candles only expose ~10 recent days | `max_history_days` clamp + metadata note |
| Kraken returned 720 bars | `/0/public/OHLC` caps at 720 candles | documented as recent-window venue |
| LightGBM `OSError: access violation` | 4.7.0 vs numpy 2.5.4 on this host | sklearn HistGradientBoosting proxy |
| `OSError` on `torch.load` walk-forward | checkpoint key is `model_state` | fall back across `model_state`/`model` |
| Pattern detectors dead on real data | strict equality (`o < prev_c`, `o == prev_o`) impossible on 24/7 crypto | tolerance-based conditions; gap-dependent patterns documented as structurally absent |
| `_three_inside`/`_three_outside` misaligned | confirmation candle treated as the pattern candle | shift the pattern by one bar, confirm on the current bar |
| `regime_breakdown` Series ambiguity | `groupby` object misuse | iterate `group.index` directly |
| test `test_features_are_causal` TypeError | `atr_wilder`/`rsi_wilder` take a DataFrame, not three series | corrected call sites |
| Asset manifest shrank to 1 series | `collect_many` overwrote the named manifest with only the current batch | manifest rows are now merged by (exchange, asset, timeframe); `--rebuild-manifest` regenerates from sidecars without network |
| Binance DOGE partition failed | transient `ConnectionResetError 10054` after 4 retries | re-ran the single partition; `--rebuild-manifest` folded it back into the batch manifest |
| Background training died mid-run | host terminates background processes when the session ends | seeds re-run in the foreground at a budget that fits the 10-min call limit |
| Duplicate `dataset_frame` fixture | fixture lived in `tests/test_dataset.py` only | moved to `tests/conftest.py` (session scope) |

### 13.10 Upgrade decisions

- **D-17 Dataset 2.0.0 is additive.** The shipped model stays on dataset 1.0.0; new data is
  stored separately with its own manifests. Metrics are never mixed across versions.
- **D-18 Recent-window venues are documented, not padded.** Kraken (720 bars) and Bitget
  (~10 days) are kept as coverage/sanity series with explicit notes.
- **D-19 Advanced features are not adopted.** The proxy ablation showed no gain; adding them
  to the network would also break the frozen 96×12 inference contract without evidence.
- **D-20 Fixed-checkpoint walk-forward.** Rolling out-of-sample evaluation of the shipped
  checkpoint is reported; per-fold retraining is documented as computationally out of scope.
- **D-21 Short-budget multi-seed.** 4 epochs/stride 4 measures seed variance honestly;
  the budget is stated in every table rather than implied to be full training.
- **D-22 One canonical copy of exchange candles.** Validated candles stay under
  `data/raw/<venue>/spot/<asset>/<tf>.parquet` with sidecar provenance; `data/processed/`
  holds the aligned panel and asset coverage only, to avoid two drifting copies.

### 13.11 Final verification (upgrade complete)

| Check | Command | Result |
|---|---|---|
| Full test suite | `./.venv/Scripts/python.exe -m pytest` | **86 passed** (5.2 s) |
| Inference, shipped checkpoint | `scripts/predict.py --input logs/smoke_input.json --warmup data/raw/binance/spot/BTC/15m.parquet` | `status: OK`, barrier probs sum to 1.0, 12 pattern scores, 6 range steps, `data_quality.valid: true` |
| Multi-seed | `scripts/train_multiseed.py --aggregate-only` | 3 seeds, val loss 1.4122 ± 0.0007, barrier acc 0.3180 ± 0.0039 |
| Comparison report | `scripts/build_final_comparison.py` | `reports/final_model_comparison.md` written |
| Data report | `scripts/build_data_report.py` | refreshed with 24 asset series + `data/processed/assets/coverage.json` |

Reports delivered: `data_expansion`, `pattern_research`, `feature_ablation`, `walk_forward`,
`multiseed`, `final_model_comparison` (all in `reports/`, each with a JSON twin except the
final comparison).

Note for the smoke test: `Plan/examples/sample_input.json` is deliberately invalid (23
duplicate/backwards timestamps) and a test asserts the validator rejects it; a valid input
was generated from the last 96 real Binance bars into `logs/smoke_input.json` (gitignore/log
artifact, not a fixture).

## 14. Autonomous runtime — continuous operation (A1–A8)

Spec: the follow-up brief asking for a self-operating system. The frozen model contract,
checkpoints and dataset were not touched; this is an orchestration layer plus operational
policy.

### 14.1 Modules added

| File | Purpose |
|---|---|
| `config/runtime.yaml` | operational policy: cadence, confirmation delay, thresholds, triggers, gates |
| `src/patron/runtime/config.py` | typed, strict (`extra=forbid`) loader + canonical status list |
| `runtime/store.py` | SQLite WAL state: candles, cycles, forecasts, evaluations, registry, jobs, events, kv |
| `runtime/collector.py` | `VenueSource` (public REST) + `StaticSource` (offline/tests, injectable failures) |
| `runtime/validation.py` | dedupe, drop forming/delay bars, OHLC/grid checks, gap + zero-volume accounting |
| `runtime/window.py` | 96 contiguous closed candles + contiguous warm-up, SHA-256 input hash |
| `runtime/engine.py` | hash-checked champion, frozen `predict()`, envelope, consistency refusal |
| `runtime/maturation.py` | independent per-horizon evaluation, step-6 barrier/momentum |
| `runtime/metrics.py` | matured-only rolling metrics, ECE, degradation rule |
| `runtime/drift.py` | feature z-score/PSI + outcome PSI against the champion reference |
| `runtime/learning.py` | matured-only dataset, capped recent share, trigger policy |
| `runtime/jobs.py` | one background candidate job, persisted state machine |
| `runtime/governance.py` | pre-registered gates, registration, promotion, rejection, rollback |
| `runtime/publisher.py` | versioned JSON outputs, latest-pointer refresh |
| `runtime/service.py` | idempotent cycle, health, sleep-until-close loop, recovery |
| `scripts/patron_service.py` | CLI: `once`, `serve`, `status`, `health`, `mature`, `rollback` |
| `schemas/forecast.schema.json` | v2 forecast envelope (embeds the frozen v1 model output) |

### 14.2 Cycle and idempotency

`FETCH/CONFIRM → VALIDATE → MATURE → METRICS → WINDOW → FORECAST → PERSIST → PUBLISH`.

- A candle is confirmed only at `close + confirm_delay_seconds` (default 20 s); the
  forming bar is dropped and counted, never used.
- `forecasts UNIQUE(symbol,timeframe,candle_ts)` + insert-or-ignore; `evaluations
  PRIMARY KEY(forecast_id, step)` + insert-or-ignore. Re-running a cycle is safe.
- The 96-candle window is rebuilt from the store each cycle, so restart recovery is
  automatic; warm-up is contiguous-only and separate from the model tokens.
- Non-OK paths (fetch failure, invalid batch, insufficient history, gap, missing
  champion) publish an explicit status and create no forecast.

### 14.3 Maturation and metrics

Per horizon, as soon as its own candle is stored. Metrics in the training target space:
absolute/percentage error of q50, pinball loss for q10/q50/q90, q10-q90 coverage,
directional correctness, and at step 6 the momentum class (ATR-normalised return, same
boundaries as training) and the triple barrier (1.5/1.0 ATR, first touch, ambiguous when
both hit intrabar). `maturity` fields say `immature` for the six-bar labels before they
can exist.

### 14.4 Monitoring, drift, triggers

- Performance: per step/head, matured rows only, with sample counts and ECE.
- Drift: live feature snapshots (stored in each forecast envelope) vs the champion's
  reference distribution (mean/std/decile edges/PSI bins), plus matured momentum
  distribution PSI. Minimum sample and threshold checks; evidence logged.
- Triggers: new matured horizons ≥ 288, weekly schedule, degradation below floor over
  ≥200 samples, confirmed drift. Cooldown 24 h between attempts, one job at a time,
  persisted via kv so restarts cannot double-start.

### 14.5 Governance

Champion is `role='champion'` in the registry, bootstrapped once from the shipped v2
checkpoint with its recorded val metrics and a stored reference distribution. Candidate
gates (configured before evaluation, all mandatory): schema_valid, probabilities_valid,
min_samples (2000 val windows), logloss_not_worse (+0.02), accuracy_not_worse (−0.01),
coverage_ok [0.60, 0.99], seed_count. Promotion is a single transaction; rollback returns
the previous champion; both are event-logged. Final test split never used for selection.

### 14.6 Live run (real Binance data, 2026-11-15)

| UTC | Result |
|---|---|
| 11:10 | `STALE_DATA` — 4 connection resets exhausted retries, no forecast (correct refusal) |
| 11:15 | `OK` forecast `20261115T104500-17d73e46` at 10:45 candle; 961 candles fetched, forming 11:00 bar dropped |
| 11:16 | `OK` forecast `20261115T110000-1d028c44`; matured the 11:00 horizon of the previous forecast |
| 11:17 | same candle → `already has an immutable forecast`; no duplicate, history unchanged |

Matured step 1: high MAPE 0.071%, low 0.285%, close 0.204%, all inside q10-q90. One
horizon is startup evidence, not an accuracy claim. Report: `reports/runtime_operations_report.md`.

### 14.7 Errors found and fixed during this phase

| Error | Cause | Fix |
|---|---|---|
| All four retries failed on a connection reset | retry reused a poisoned keep-alive connection | `_get_json` closes the session on connection/chunked errors before retrying; regression test added |
| `AttributeError: ForecastResult has no attribute forecast_id` | missing convenience property | added property reading the envelope |
| Rolling metrics always empty | `OFFSET window-1` subquery returned NULL when fewer forecasts existed | rewrote as `WITH recent ... LIMIT ?` |
| `last_cycle` reported an old failure as latest | ordered by `candle_ts`, failed attempts carry a synthetic timestamp | order by `finished_at DESC, rowid DESC` |
| `latest_forecast.json` marked stale immediately | publisher compared against wall clock, not the cycle clock | `refresh_latest(..., now=)` + `publish_status(now=)` |
| `name 'v' is not defined` in metrics | bad comprehension flattening MAPE lists | flatten the per-field lists explicitly |
| Gap detection crashed on `.loc` with mismatched index | boolean Series indexing on a `tail` slice | positional numpy comparison |
| Promotion never completed in one tick | state machine needed a second poll after TRAINING | custom-command path finalises inline |
| `KeyError: 'val_samples'` in gating | read before assignment in `load_run_metrics` | initialise to `None` and set once |
| Health stayed healthy after a failed cycle | failed path returned before `mark_cycle` | `_mark_failed_cycle` records attempts |

### 14.8 Verification

`./.venv/Scripts/python.exe -m pytest` → **120 passed** (86 prior + 34 runtime/exchange).
New files: `tests/test_runtime_core.py` (17), `tests/test_runtime_lifecycle.py` (16),
plus a retry-pool regression in `tests/test_exchange_data.py`. Live checks:
`scripts/patron_service.py once/status/health` executed against Binance; the published
envelope validated against `schemas/forecast.schema.json` and the nested stdout against
the frozen `schemas/output.schema.json`.

### 14.9 Decisions

- **D-23 Runtime policy is separate from model config.** Thresholds change operations, not
  model semantics; `config/model_config.yaml` stays frozen.
- **D-24 SQLite, not a broker.** Single-machine, crash-safe, auditable, no new service
  dependency. Forecast payloads are also written as immutable JSON files.
- **D-25 The envelope embeds the v1 output.** No schema change to `output.schema.json`, so
  the frozen inference contract stays valid and is still validated independently.
- **D-26 Per-horizon maturation with explicit immaturity.** Six-bar labels are marked
  immature rather than approximated.
- **D-27 Conservative gates.** Missing evidence (no evaluation report) fails promotion;
  the test split is never a selection input.
- **D-28 Signals, not verdicts.** Drift and degradation make training eligible; they never
  promote a model.
- **D-29 Formation candles are counted and excluded.** `PROVISIONAL` is reserved for a
  separate view; it never contaminates a forecast or a training row.

### 14.10 Limitations (stated, not hidden)

- No live candidate retrain completed here: the trigger requires 288 matured horizons
  (~3 days) and a real epoch costs minutes on this CPU. Promotion/rejection/crash/rollback
  are verified with test doubles, not a real candidate.
- Live performance holds one matured horizon — below every configured minimum.
- Single-machine worker loop only; `reports/live/*.json` is the API surface.
- Regime-sliced runtime metrics are not wired (offline `evaluation/regimes.py` exists).

## 15. Advanced training upgrade — T1 audit and T2/T3 design

Brief: improve *how* the frozen v2 network learns. Architecture, 272,618 params, 96×12 input,
feature/label/inference contracts and the champion checkpoint stay untouched.

### 15.1 Method

Read-only audit of the training stack plus one diagnostic pass
(`scripts/audit_diagnostics.py` → `reports/training_upgrade/audit_evidence.json`), validation
split only. No training launched, no champion file touched, no config edited.

### 15.2 Findings (evidence in `reports/training_upgrade/training_audit.md`)

- Loss terms weighted by raw magnitude → objective shares barrier 75.3 %, momentum 22.7 %,
  pattern 2.0 %, **quantile 0.036 %**. Trunk gradient norms 0.611 / 0.500 / 0.082 / **0.0026**
  (quantile is 230× smaller than barrier).
- Quantile head has no conditional location: median-regression slope for close **−0.013**,
  10–90 coverage **0.908** vs nominal 0.80, width 0.0139 vs mean |target| 0.00256; median MAE
  on test (0.002622) is worse than persistence (0.002541). Pinball (0.000974) improves only
  because the band is wide.
- Barrier operating point is mis-set by inverse-frequency weights: val accuracy 0.3769 vs
  majority 0.4731; prior-corrected argmax on the same logits gives 0.4860 (AUC 0.5943
  unchanged). A one-bar logistic regression gets 0.4708 test accuracy.
- Momentum head at chance: acc 0.2386, log loss 1.5934 (uniform 1.6094), sideways recall 0.136;
  predicted 8,195 strong_bullish + 8,967 bullish vs 6,274 / 4,127 actual.
- Pattern head predicts base rates: mAP 0.0852, no `pos_weight`, 2 % objective share.
- Selection = total val loss (75 % barrier); best epoch 3 of 15, 12 wasted epochs ≈ 51 min,
  and epoch 1 had better barrier accuracy (0.4091) than the selected epoch (0.3769).
- 96-bar windows at stride 1: 122,608 windows ≈ 1,277 independent chunks (95/96 overlap);
  train/val gap grows to 0.263 nats after epoch 2.
- Gradient cosines are all ≥ −0.009 → no destructive conflict; gradient surgery is unnecessary
  and would cost 4 backward passes per step.
- Not the problem: leakage (scaler/splits/windows tests pass), missing candles (0.58 % masked),
  momentum imbalance (28,984–39,802 per class), feature nulls (≤0.13 %), quantile crossing (0).

### 15.3 Prerequisite fix exposed by the smoke run

`scripts/train.py --stride` subsampled **all** splits before splitting, so a “stride 2” run
halved validation (26,262 → 13,125) and was not comparable to the evaluation report.
Added `train_stride` to `datasets.windows.make_datasets` / `loader.prepare_data` and
`--train-stride` to the CLI: training windows are subsampled **after** the chronological
split, validation/test keep full size. Default behaviour unchanged; new test
`tests/test_dataset.py::test_train_stride_keeps_validation_and_test_intact`.
Measured: 61,304 train / 26,262 val, 125.5 s per epoch including validation.

### 15.4 T2/T3 design (pre-registered in `plan/ADVANCED_TRAINING_UPGRADE.md`)

- E-series: control (3 seeds) → train-only stride 1/2/4 → composite selection + patience 6 →
  warmup+cosine → weight decay 1e-3/5e-3 → clip 0.5/2.0 → OneCycle → batch/accumulation →
  head LR groups.
- L-series: loss normalisation by measured share (55/20/15/10), uncertainty weighting,
  sqrt class weights vs unweighted CE + validation decision rule, focal/smoothing,
  pattern `pos_weight`, quantile share 20 % + head LR, then combination ablation.
- Promotion gates fixed **before** results: barrier macro-F1 ≥ 0.3885, BA ≥ 0.4091, log loss ≤
  1.0636, ECE ≤ 0.05; momentum acc ≥ 0.2486 or macro-F1 ≥ 0.2454 with log loss ≤ 1.5834;
  quantile pinball ≤ 0.000952 with coverage 0.78–0.86 and median MAE ≤ 0.00250; pattern mAP ≥
  0.0952; no head regression; 3-seed stability; walk-forward retraining; regime floor; rollback.
- Compute measured, not guessed: ~12.5 min per 6-epoch run; T2 ≈ 3 h, T3 ≈ 4.5 h, total
  upgrade ≈ 13 h CPU across sessions. No cloud, one run at a time, 6 threads.

### 15.5 Verification

- `./.venv/Scripts/python.exe -m pytest` → **121 passed** (120 + the train-stride test).
- `scripts/audit_diagnostics.py` ran end to end and wrote the evidence JSON.
- Two 1-epoch smoke runs: legacy `--stride 2` (61,301 train / 13,125 val, 122.5 s) and
  `--train-stride 2` (61,304 train / 26,262 val, 125.5 s). Both loss ≈ 1.435, i.e. healthy but
  untrained; they are diagnostics, not candidates, and are not compared with v2.

### 15.6 Limitations (stated, not hidden)

- **No T2/T3 experiment has been run**, so no improvement is claimed anywhere. v2 remains
  champion and `config/model_config.yaml` is unchanged.
- Diagnostics use one checkpoint and the validation split; seed-level uncertainty on the
  diagnostic statistics themselves is not quantified.
- The audit's class-weight conclusion (F3) is a decision-rule analysis, not proof that
  unweighted training yields higher macro-F1; that is exactly what L3 tests.
- Gates are champion-relative and assume the v2 reference numbers are stable; a future
  dataset rebuild changes them and requires re-registration.

### 15.7 Next phase

T2 E0 control + E7 stride ablation (6 epochs, seeds 42/7/2026), then T3 L-series. Exact
command in `plan/ADVANCED_TRAINING_UPGRADE.md` §11.

## 16. Public testing release — v1.0.0-beta.1 (R1)

Brief: turn the repository into an installable, documented, secure, testable release and
prepare it for GitHub. **The user explicitly asked for no commit, tag or push**, so the
work exists only in the working tree; publication commands are in
`reports/release/FINAL_RELEASE_REPORT.md` §7.

### 16.1 Delivered

- **Licence**: official Apache-2.0 text from apache.org (202 lines), `NOTICE`,
  `pyproject` `license = "Apache-2.0"` + `license-files`, wheel ships
  `dist-info/licenses/{LICENSE,NOTICE}`. Copyright holder taken from the only git commit
  author (Al Shahriar sowan); no invented names.
- **Version scheme**: package `1.0.0b1` (PEP 440) for release `v1.0.0-beta.1`; the model
  version in `config/model_config.yaml` stays `1.0.0` (different artefact).
- **CLI**: `src/patron/cli.py` + `__main__.py`: health, train (with `--dry-run`),
  evaluate, predict, runtime {status,once,serve,mature,rollback,health}, experiment
  {list,compare}. Exit codes 0/1/2/3/4. Legacy `scripts/*.py` still work.
- **Health**: `src/patron/health.py`, 12 checks, PASS/WARN/FAIL, `--json`, `--strict`,
  read-only DB open, home paths redacted to `~`.
- **Security**: `load_checkpoint` now uses `weights_only=True` (explicit `allow_unsafe`
  opt-in only), `run_walk_forward` uses it too; `.env.example`; `.gitignore` additions;
  `scripts/scan_release.py`; `reports/security/security_audit.md`.
- **Packaging**: schemas duplicated into `src/patron/schemas/` so the wheel is
  self-contained; a contract test asserts byte-identity with `schemas/`; `PROJECT_ROOT`
  falls back to CWD when installed.
- **Docs**: README rewrite plus CHANGELOG, RELEASE_NOTES, MODEL_CARD, DATASET_CARD,
  REPRODUCIBILITY, INSTALLATION, QUICKSTART, CONFIGURATION, LIMITATIONS,
  THIRD_PARTY_NOTICES, SECURITY, CONTRIBUTING, CODE_OF_CONDUCT (official v2.1).
- **CI**: `.github/workflows/{ci,security,release}.yml` + issue/PR templates. Release job
  needs the protected `release` environment for manual approval.
- **Release builder**: `scripts/build_release.py` → staging scan, source zip/tar.gz,
  wheel+sdist, release dir, `SHA256SUMS.txt` (LF endings), `BUILD-MANIFEST.json`,
  member-count verification and checksum re-verification.
- **Tests**: +41 (health, CLI, security, contracts, training smoke) → **162 total**.

### 16.2 Verification (exact)

- `python -m pytest` → **162 passed** (3 pre-existing third-party warnings).
- `python -m patron health` → **PASS (12 pass, 0 warn, 0 fail)**.
- `python scripts/scan_release.py` → clean; staged tree clean too.
- `pip check` → clean; `pip-audit` → clean after setuptools 78.1.0 → 84.2.1 (5 advisories
  found and fixed). `torch 2.4.1+cpu` and `patron 1.0.0b1` are skipped by pip-audit
  (local version identifiers not on PyPI) — recorded as a residual gap.
- Evaluation smoke reproduced reference test metrics exactly; inference smoke produced a
  schema-valid OK forecast; runtime offline replay produced `OK`.
- `scripts/install.ps1` ran end to end (health PASS); `install.sh`/`run_*.sh` passed
  `bash -n`; all `.ps1` passed the PowerShell parser.
- Fresh venv: deps + wheel installed; `python -m patron --help` and a real prediction ran
  from outside the repo.
- Release: 161 files staged, 59 files checksummed, `sha256sum -c` all OK
  (rebuilt after the integration guide: 162 staged, 60 checksummed, still all OK).

### 16.3 Errors found and fixed

1. PEP 639 conflict: `license = "Apache-2.0"` + `License ::` classifier → editable install
   failed. Removed classifier; build requires `setuptools>=84.1`.
2. Unsafe `torch.load` in trainer and walk-forward → safe loading.
3. Health failed on an installed wheel (schemas only resolved from repo root) → package
   schema fallback and CWD root fallback.
4. Health printed `sklearn==unknown`/`yaml==unknown` → distribution-name mapping.
5. Health exposed the home directory → redaction.
6. `SHA256SUMS.txt` CRLF broke `sha256sum -c` → `newline="\n"`.
7. Tests depended on git-ignored `Plan/` fixtures → moved to `examples/` (and the
   deliberately invalid payload is now `examples/invalid_input.json`).
8. README claimed class weights make the model predict `tp_first` 51 % of the time; the
   measured validation rate is 38 % → corrected, along with the wrong logistic-regression
   macro-F1 and the misleading pinball-vs-persistence comparison.
9. Runtime smoke wrote a replay forecast into the live ledger/history and replaced
   `latest_forecast.json`; artifacts removed and the pointer restored from `patron.db`
   with a recomputed `stale` flag (now `true`, because the real last forecast is hours old).

### 16.4 Decisions

- **D-33 Apache-2.0** for code/docs/weights produced by the project; market data is never
  redistributed (Binance terms) and is not covered by the licence.
- **D-34 Package schemas are duplicated on purpose** (`schemas/` canonical,
  `src/patron/schemas/` for wheels), guarded by a byte-identity test.
- **D-35 Version split**: package `1.0.0b1` vs model `1.0.0`; documented in README and
  CONFIGURATION so neither is mistaken for the other.
- **D-36 Release directory is generated**, never hand-edited; canonical docs live at the
  repository root and are copied by the builder.

### 16.5 Limitations of this phase

- CI/security/release workflows have **never run on GitHub** (no push authorised); local
  equivalents pass and the YAML parses.
- macOS untested; no linter/formatter gate; CVE auditing manual; wheel builds are not
  bit-reproducible (embedded timestamps) though source archives use fixed mtimes.
- No checkpoint or dataset shipped; model quality unchanged from §15's measured baseline.
- `dist/` is git-ignored, so release artifacts are local-only until attached to a GitHub
  Release.

### 16.6 Universal integration guide (added after the release build)

`INSTRUCTION.md` (17 sections) was written against the release and copied
into the release dir and both archives by `scripts/build_release.py`
(added to `INCLUDE_FILES`, `REQUIRED_DOCS` and the release-dir copy list).

Verified before publishing: 17 executable snippets (Python API, DataFrame→payload,
subprocess, sqlite persistence, ledger read, dashboard shaping, runtime `cycle()`,
`RuntimeStore` on a DB **copy**, health API, low-level model load, error handling); the
embedded forecast and input candles come from a real run, not invented; all JSON blocks
parse; 0 broken relative links; every CLI command/flag checked with `--help`.

Two snippets are explicitly marked pseudocode (FastAPI endpoint, the `latest_closed_candles`
hook in the polling loop); the runtime's unattended promotion is labelled experimental.

### 16.7 Next steps

1. Maintainer: commit/tag/push per the final report, then watch the first CI run.
2. Re-verify on Linux and record it.
3. Decide on publishing the reference checkpoint as a separate licensed artifact.
4. Start T2 optimization experiments (`plan/ADVANCED_TRAINING_UPGRADE.md` §4).

## Important Notes for the Next Agent

- Use `./.venv/Scripts/python.exe`; system Python has none of the packages.
- Windows + bash: forward slashes, POSIX commands.
- The dataset ends 2026-11-14 12:30 UTC (the current month is REST-backed and grows).
- `data/features/BTCUSDT_dataset.parquet` is the single supervised artifact; do not rebuild features piecemeal.
- Fixed spec values that must not change: TP 1.5×ATR14, SL 1.0×ATR14, horizon 6, quantiles [0.1, 0.5, 0.9], momentum bounds [-1.0, -0.35, 0.35, 1.0], 12 features, 272,618 params, split 70/15/15, purge/embargo 6.
- Training hyperparameters (loss weights, lr, wd, batch, patience, clip, seed) are the **champion's** recipe and stay in `config/model_config.yaml`; T2–T12 vary them only in separate experiment configs, and only a promoted candidate (gates in `plan/ADVANCED_TRAINING_UPGRADE.md` §7) may change the champion config. See D-30.
- Inference needs 384 prior 15m candles; `data/clean/BTCUSDT/latest_input.json` is a real 96-bar sample generated from the clean parquet.
- Training is CPU-bound: ~3.8–4.3 min/epoch at stride 1, ~2.1 min/epoch at `--train-stride 2`; do not run evaluation concurrently (it starved and hit the 600 s timeout once).
