# PATRON — Large-Scale Data Expansion, Market Intelligence & Advanced Training

Status: implementation roadmap, written before code (per the project's decision rule).
The existing PATRON v2 system (BTC/USDT 15m, 96×12 → 4 heads) is preserved as the
baseline; nothing below deletes or overwrites the v2 checkpoint
(`experiments/patron_v2_20261114-203859/best.pt`) or its dataset
(`data/features/BTCUSDT_dataset.parquet`).

## 0. Non-negotiables

1. BTC/USDT remains the **only** supervised target. Other symbols are auxiliary
   context / pretraining samples, never relabelled as BTC outcomes.
2. No fabricated data. Every venue/timeframe/asset column is either downloaded and
   checksummed or explicitly absent and documented.
3. Causal only: features and pattern detections at time `t` use candles closed at
   or before `t`.
4. The untouched final holdout of v1 (`2026-02-12 → 2026-11-14`) is **not** used for
   any training decision. New experiments use a new, later holdout on the new
   dataset version and are reported separately from v2's numbers.
5. CPU-only budget: streaming downloads, parquet partitions, lazy windows,
   resumable runs.

## 1. What already exists (baseline to preserve)

| Area | v2 state |
|---|---|
| Data | Binance spot BTC/USDT 15m/1h/4h, 2021-11 → 2026-11, one 5-bar gap flagged |
| Features | fixed 12: open/high/low/close rel, volume log-rel, body/range, ATR%, RSI, EMA9/21 gaps, volume spike, HTF trend |
| Patterns | 12 rule-based tags used as auxiliary BCE targets |
| Labels | triple barrier (1.5/1.0 ATR, 6 bars), 6×3 relative quantiles, 5-class momentum |
| Model | CNN(32/64/64) → BiLSTM(64/dir) → 4-head attention → heads; 272,618 params |
| Training | AdamW 3e-4, ReduceLROnPlateau(0.5, 3), clip 1.0, patience 12, batch 128 |
| Evaluation | chronological 70/15/15 + purge/embargo, temperature scaling, baselines |
| Inference | 96×12 JSON in → schema-validated JSON out, `NO_OUTPUT` without warm-up |
| Tests | 44 passing |

## 2. Upgrade architecture

```
data/
  raw/<exchange>/<market>/<symbol>/<timeframe>/   # immutable, per-venue partitions
  processed/exchange/<exchange>/<symbol>/          # validated, canonical candles
  processed/unified/panel_<symbol>.parquet         # aligned multi-venue panel (no blind merge)
  processed/patterns/<version>/                    # pattern occurrences + outcomes
  processed/assets/<symbol>/                       # auxiliary assets (context/pretraining)
  manifests/                                       # provenance, checksums, coverage
```

New packages:

```
src/patron/data/
  markets.py      # venue registry: symbol maps, market types, limits, licence notes
  venues.py       # per-venue REST adapters -> canonical candle schema
  collect.py      # resumable collection, manifests, checksums, quality gate
  quality.py      # exchange-specific validation, outliers, volume sanity, staleness
  align.py        # multi-venue UTC alignment with tolerance; never blind-merges
  timeframes.py   # 1m..1d canonical map + causal resampling/alignment

src/patron/features/advanced.py   # grouped causal features + regimes, ablation-ready
src/patron/patterns/
  registry.py     # >=100 patterns: definition, math, context, confidence, reference
  detectors.py    # primitives shared by the registry
  structures.py   # chart structures (separate category, >=10)
  dataset.py      # pattern occurrences x future outcomes 1/2/3/6/12/24 candles
  analysis.py     # performance by pattern x regime
src/patron/evaluation/
  regimes.py      # trend/volatility regime labelling + regime metrics
  walkforward.py  # rolling out-of-sample evaluation of a fixed checkpoint
  multiseed.py    # seed-variance aggregation helpers
src/patron/training/multiseed.py  # reproducible multi-seed runner
scripts/collect_market_data.py  build_pattern_dataset.py  run_feature_ablation.py
        run_walk_forward.py     train_multiseed.py
```

## 3. Phases

| # | Phase | Deliverable | Verification |
|---|---|---|---|
| U1 | Venue registry + adapters | `markets.py`, `venues.py` | unit tests on pagination/canonicalisation with synthetic payloads |
| U2 | Collection + quality gate | multi-venue BTC 15m dataset, manifests, checksums | `reports/data_expansion_report.md` |
| U3 | Multi-asset collection | 10 symbols, spot, 15m | coverage table, symbol-mapping tests |
| U4 | Multi-timeframe pipeline | 1m/5m/15m/30m/1h/4h/1d causal resampling | alignment + leakage tests |
| U5 | Advanced features | grouped features, regimes, ablation switches | causality + ablation report |
| U6 | Pattern registry | ≥100 candle patterns, ≥10 structures, sources | registry tests (count, shape, direction, no future access) |
| U7 | Pattern dataset | occurrences + outcomes + regime breakdown | leakage tests, `pattern_research_report.md` |
| U8 | Training experiments | v3 feature-set run(s), 3 seeds | `multiseed_report.md`, no test-set selection |
| U9 | Advanced evaluation | walk-forward, regime, calibration, coverage | `walk_forward_report.md`, `final_model_comparison.md` |
| U10 | Documentation | README, memory, roadmap, reports | acceptance checklist below |

## 4. Dataset versioning & protocol

- `dataset_version` `1.0.0` = v2 artifact (unchanged, still used by the shipped
  inference model).
- `dataset_version` `2.0.0` = expanded multi-venue/multi-asset/advanced-feature
  artifact. New splits, new holdout, new number set. **v1 and v2/v3 metrics are
  never mixed in one table without an explicit version column.**
- Holdout for 2.0.0: last 10% of the 15m history (chronological), touched once at
  the end. Purge/embargo ≥ horizon (6 bars) at every boundary.

## 5. Compute plan on i5-9400F / 16 GB / CPU

- Downloads: streaming, per-month/per-request batches, parquet partitions.
- Feature build: vectorised pandas over one parquet at a time.
- Training: batch 128, lazy windows, checkpoint every epoch, resumable via
  `--resume`. Full-budget (100–200 epoch) runs documented as an optional
  cloud-GPU workflow; local runs state their exact budget.
- Reported numbers always state: seed, epochs, dataset version, feature version.

## 6. Acceptance criteria (from the brief)

1. Expanded datasets downloaded + validated.
2. Manifests/provenance with checksums.
3. Pattern registry + documentation.
4. Feature causality tests pass.
5. Inference compatibility preserved.
6. Training reproducible (config + seed + dataset version recorded).
7. Walk-forward evaluation completed.
8. Multi-seed results documented.
9. Final model compared with PATRON v2.
10. All tests pass.
11. README + `plan/memory.md` updated.

Any criterion that cannot be met on this hardware is listed explicitly as a
limitation rather than silently skipped.

## 7. Outcome (status after implementation)

| # | Criterion | Result |
|---|---|---|
| 1 | Expanded datasets downloaded + validated | ✅ 6 venues × BTC 15m, 24 asset series, quality sidecars + checksums |
| 2 | Manifests / provenance | ✅ `data/manifests/*.json`, merged per batch, rebuildable from sidecars |
| 3 | Pattern registry + documentation | ✅ 103 candlestick patterns + 16 structures, formula/conditions/context/reference each |
| 4 | Feature causality tests pass | ✅ 12 v1 features, 34 advanced features, MTF alignment, pattern truncation |
| 5 | Inference compatibility preserved | ✅ v2 checkpoint still predicts (`status: OK`, 12 patterns, 6 range steps) |
| 6 | Training reproducible | ✅ seed + dataset/feature version in every run's JSONL `start` event |
| 7 | Walk-forward evaluation | ✅ 4 rolling blocks on the fixed checkpoint (retraining per fold documented as out of scope) |
| 8 | Multi-seed results | ✅ 3 seeds at 4 epochs/stride 4, dispersion reported |
| 9 | Final comparison with PATRON v2 | ✅ `reports/final_model_comparison.md` — no variant beat v2 |
| 10 | All tests pass | ✅ 86 tests |
| 11 | README + `plan/memory.md` updated | ✅ |

Deviations, stated rather than hidden:

- Kraken capped at 720 bars and Bitget at ~10 days → kept as recent-window series.
- Per-fold retraining in walk-forward was not run (~1 h/fold on this CPU); a fixed
  checkpoint was rolled forward instead.
- Multi-seed budget is 4 epochs / stride 4; the host kills background jobs at session
  end and foreground calls are capped at 10 minutes.
- The advanced 34-feature set lost the ablation and was not adopted.

## 8. Autonomy upgrade (A1–A8) — implemented

Follow-up brief: turn the research prototype into an unattended, self-monitoring
forecasting service without changing the model contract.

| # | Phase | Deliverable | Status |
|---|---|---|---|
| A1 | Persistent runtime state | SQLite store (candles, cycles, forecasts, evaluations, registry, jobs, events) | ✅ |
| A2 | Reliable ingestion | venue adapter with retry/backoff, confirmation delay, dedupe, reconciliation of revised bars | ✅ |
| A3 | Rolling inference + immutable ledger | 96-candle window rebuilt from store, one forecast per candle, JSON + DB copies | ✅ |
| A4 | Per-horizon maturation | each horizon scored when its own candle closes; six-bar labels only when mature | ✅ |
| A5 | Monitoring + drift | matured-only rolling metrics per step/head, feature/outcome PSI vs champion reference | ✅ |
| A6 | Controlled continuous learning | matured-only dataset with capped recent share, trigger policy with cooldown, background job | ✅ (machinery; live candidate not run) |
| A7 | Champion/challenger governance | pre-registered gates, atomic promotion, rejection records, rollback | ✅ (test doubles for promotion) |
| A8 | Reliability, tests, docs | 120 tests, health endpoint, recovery paths, README + memory + operations report | ✅ |

Deviations, stated rather than hidden:

- Live candidate retraining was not executed: the evidence trigger needs 288 matured
  horizons (~3 days of continuous operation) and real epochs are minutes long on this CPU.
  Promotion, rejection, crash isolation and rollback are covered by tests with stand-in
  runners and candidate artefacts.
- The runtime is a single-process worker loop with subprocess training, not a broker-based
  distributed system; `reports/live/*.json` is the API surface.
- Regime-sliced live metrics are not wired yet; the offline regime labeller exists.
