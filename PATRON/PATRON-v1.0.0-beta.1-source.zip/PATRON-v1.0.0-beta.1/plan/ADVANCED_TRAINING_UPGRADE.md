# PATRON — Advanced Training Intelligence Upgrade

> Working plan for phases T1–T12 of the training-methodology brief.
> Model architecture, parameter count (272,618), input contract (96 × 12), feature schema,
> label definitions and inference/output contract are **frozen**. What changes is *how the
> same network is trained*, measured and promoted.

## 0. Frozen vs in scope

| Frozen | In scope (separate experiment configs, never the shipped config) |
|---|---|
| `models/patron_net.py` layers, 272,618 params | loss weighting, focal/smoothing, `pos_weight` |
| 12 features, 96 candles, oldest→newest | optimizer, scheduler, warmup, LR groups, clipping |
| Triple barrier 1.5/1.0 ATR, horizon 6, momentum bounds [-1, -0.35, 0.35, 1.0], quantiles 0.1/0.5/0.9 | batch size, accumulation, sampling stride, sample weights |
| 70/15/15 chronological split, purge 6, embargo 6 | checkpoint selection metric, early-stopping rule |
| `data/features/BTCUSDT_dataset.parquet` (sha `f0d486…b4421`) | experiment bookkeeping, evaluation depth, promotion gates |
| `experiments/patron_v2_20261114-203859/best.pt` (champion) | candidate checkpoints under `experiments/` |

**D-30.** Training hyperparameters are re-openable *only* through new config files that
inherit from `config/model_config.yaml`; the shipped config keeps describing the champion
until a candidate passes every gate in §7 and is promoted deliberately.

**D-31.** Validation is the only selection surface. The test split is evaluated **once**, for
the single candidate that already passed validation and walk-forward gates.

**D-32.** A candidate is never compared to the champion on accuracy alone. Every claim names
the head, the metric, the split, the seed count and the reference value from §7.2.

## 1. Baseline reference (must be quoted exactly)

Validation (n = 26,262) and test (n = 26,269), `patron_v2`, from `reports/evaluation_report.json`:

| Head | Metric | Val | Test |
|---|---|---|---|
| Barrier | accuracy | 0.3769 | 0.3813 |
| Barrier | balanced accuracy | 0.4041 | 0.4093 |
| Barrier | macro-F1 | 0.3785 | 0.3826 |
| Barrier | log loss | 1.0586 | 1.0592 |
| Barrier | ECE | 0.0355 | 0.0287 |
| Barrier | ROC-AUC OvR | 0.5943 | 0.5937 |
| Momentum | accuracy | 0.2386 | 0.2382 |
| Momentum | macro-F1 | 0.2254 | 0.2244 |
| Momentum | log loss | 1.5934 | 1.5939 |
| Quantile | pinball | 0.001002 | 0.000974 |
| Quantile | 10–90 coverage | 0.908 | 0.903–0.907 |
| Quantile | median MAE (close) | — | 0.002622 |
| Pattern | mAP | 0.0852 | 0.0864 |

Context (test split): majority barrier accuracy 0.4692; logistic regression on one bar 0.4708 / macro-F1
0.2389; persistence close MAE 0.002541; seed std of val barrier accuracy ≈ 0.0039 (3 seeds).
Any improvement smaller than ~0.008 barrier accuracy is inside seed noise and will not be
claimed.

## 2. Phase status

| Phase | Deliverable | Status |
|---|---|---|
| T1 Audit | `reports/training_upgrade/training_audit.md`, `audit_evidence.json`, `scripts/audit_diagnostics.py` | ✅ complete |
| T2 Optimization design | §4 below (E-series, budget, decision rule) | ✅ design complete — runs pending |
| T3 Loss design | §5 below (L-series, budget, ablations) | ✅ design complete — runs pending |
| T4 Hard examples | §6.1 design + `hard_example_analysis.md` after runs | ⏳ designed, not started |
| T5 Regimes | §6.2 design | ⏳ designed, not started |
| T6 Patterns | §6.3 design (within the frozen 12-feature input) | ⏳ designed, not started |
| T7 Error intelligence | §6.4 design | ⏳ designed, not started |
| T8 Continual training | §6.5 design (extends `src/patron/runtime/learning.py`) | ⏳ designed, not started |
| T9 Experiment runner | §6.6 design | ⏳ designed, not started |
| T10 Evaluation | §6.7 design | ⏳ designed, not started |
| T11 Governance | §6.8 + §7 gates | ⏳ designed, not started |
| T12 Integration | §6.9 | ⏳ not started |

No phase may modify the champion. Every phase ends with: focused tests, a recorded
experiment/evidence artifact, a `plan/memory.md` update, and a stated next phase.

## 3. Measurement protocol (applies to every experiment)

1. **Data**: dataset 1.0.0 unchanged; train windows at `stride` ∈ {1,2,4} (training only);
   validation and test always stride 1 so numbers are comparable to the baseline.
2. **Budget**: 6 epochs per exploratory run (validation peaks by epoch 3–5; 15 epochs is
   wasted CPU), 3 seeds for anything that is a candidate for integration.
3. **Selection**: on validation only, using the composite in §7.3, never on test.
4. **Reporting**: every run writes `training_history.json`, `train_log.jsonl`, plus a
   registry row (T9) with dataset hash, config hash, seed, stride, wall-clock, metrics.
5. **Noise**: differences below seed noise are reported as "no measurable difference".
6. **Conflict resolution**: if two variants are within noise on the primary metric, prefer the
   simpler one (fewer new mechanisms).

## 4. T2 — Advanced optimization experiment design

Reference recipe (E0) = champion recipe: AdamW(3e-4, wd 1e-4), plateau(0.5, 3), clip 1.0,
batch 128, stride 1, patience 12, select on total val loss.

| ID | Factor | Levels | Compared against | Rationale from audit |
|---|---|---|---|---|
| E0 | control | champion recipe, stride 2, 6 epochs, seeds 42/7/2026 | — | gives the seed band for later decisions |
| E1 | schedule | 2 % warmup + cosine to 3e-5 over 6 epochs | E0 | no warmup today; LR peaks too early (F8) |
| E2 | schedule | OneCycle(max_lr 3e-4, pct_start 0.25) | E1 | tests whether a single-cycle shape beats cosine on a 6-epoch budget |
| E3 | weight decay | wd 1e-3, 5e-3 | best of E1/E2 | val turns at epoch 3 → regularisation is under-set (F7/F8) |
| E4 | clipping | 0.5, 2.0 | best so far | 1.0 is untested against the actual gradient norms (0.6 barrier) |
| E5 | batch / accumulation | 256 × 1; 64 × 2 accum | best so far | effective batch must stay comparable; step cost measured at 0.18–0.21 s |
| E6 | selection/stopping | composite metric (§7.3), patience 6 | total val loss, patience 12 | selected checkpoint is worse than epoch 1 (F6) |
| E7 | stride | 1 vs 2 vs 4 via `--train-stride` (validation/test stay full size) | E0 | 95/96 window overlap inflates effective epochs (F7) |
| E8 | LR groups | heads 3× trunk LR | best so far | heads are fresh and starved (F1/F4) |

Execution order: E0 (3 seeds) → E7 → E6 → E1 → E3 → E4 → E2 → E5 → E8. Stop the series when
the best variant is within noise of E0; carry at most three variants into T3.

**Cost (measured, not estimated)**: `--train-stride 2` → 479 steps/epoch over 61,304 windows,
**125.5 s for one epoch including the 26,262-window validation pass**, so a 6-epoch run is
**≈ 12.5 min**. E0 (3 seeds) ≈ 40 min; full series (≈ 14 runs) ≈ **3 h CPU**. No cloud;
nothing concurrent (single process, 6 threads).

## 5. T3 — Multi-task loss experiment design

Starting point L0 = 1.0 / 0.5 / 0.2 / 0.15 with inverse-frequency barrier weights and no
pattern `pos_weight`. Measured shares: 75.3 / 0.04 / 22.7 / 2.0 (barrier / quantile /
momentum / pattern).

| ID | Change | Target share (barrier / quantile / momentum / pattern) | Success criterion |
|---|---|---|---|
| L1 | loss normalisation: weight = share ÷ mean raw loss at init | 55 / 20 / 15 / 10 | quantile slope > 0.10; pattern mAP > 0.09 |
| L2 | uncertainty weighting (learned `log σ²` per task, Kendall 2018), initialised at L1 | learned | beats L1 on composite without a head regression |
| L3a | barrier: sqrt-inverse-frequency weights | 55 | accuracy ≥ 0.44 with BA ≥ 0.40 |
| L3b | barrier: unweighted CE + validation-chosen decision rule | 55 | same criterion, simpler mechanism |
| L4 | barrier: focal γ=1 or label smoothing 0.02 on the L3 winner | 55 | log loss −0.01 without BA loss |
| L5 | momentum: label smoothing 0.05 + sqrt weights | 15 | log loss ≤ 1.5834 or acc ≥ 0.2486 |
| L6 | pattern: per-tag `pos_weight` = sqrt(neg/pos), cap 20 | 10 | mAP ≥ 0.0952 |
| L7 | quantile: share 20 % + head LR 3× + uniform per-step weights | 20 | pinball ≤ 0.000952, coverage 0.78–0.86, median MAE ≤ persistence |
| L8 | combination of winners | as measured | passes all §7 gates on validation |

Deliberately **not** in the first grid:

- **GradNorm / PCGrad / gradient surgery.** Measured pairwise cosines are 0.365 (barrier vs
  momentum), 0.223, 0.038, 0.018, 0.007, −0.009. There is no destructive conflict to resolve;
  the problem is scale (0.611 vs 0.0026). Surgery would cost 4 backward passes per step for no
  measured benefit.
- **Architecture changes, extra inputs, extra heads** — frozen contract (§0).
- **Class-balanced resampling of the barrier** — the labels already yield a workable
  operating point via L3; resampling would change the effective prior and complicate
  calibration.

**Cost**: 10 runs × 2 seeds × 13 min ≈ **4 h**; run in one 6-epoch wave, then 3-seed
confirmation of the winner ≈ 40 min.

## 6. Roadmap for T4–T12

### 6.1 T4 — Hard-example learning

- **Hardness must be label-derived or out-of-fold**, never from future data: (a) realised
  volatility-expansion z-score at the window end, (b) barrier ambiguity and near-touch
  distance in the label horizon, (c) disagreement of outcomes among windows ending within
  ±3 bars of each other (measurable from training labels only), (d) out-of-fold residuals
  from the previous walk-forward fold — never from test.
- Weight `w = clip(h^κ, 1, w_max)` with `κ ≤ 1`, `w_max ≤ 5`, and total sampled mass ≤ 20 %
  above uniform; cap per-sample reuse across epochs (track counts).
- Diagnostic deliverable `reports/training_upgrade/hard_example_analysis.md`: error rates for
  false breakouts, traps, volatility expansion, reversals, low-volume breakouts, using
  matured outcomes and the causal regime labeller.
- Control: ordinary sequential/shuffled training at the same budget. Keep val/test
  distributions untouched.
- Cost: hardness table build ≈ 5 min; 4 runs × 13 min ≈ 1 h.

### 6.2 T5 — Regime-aware training

- Reuse `evaluation/regimes.py` (expanding, shifted thresholds — causal).
- Weights target equal-ish regime mass with a **cap**: no regime may exceed 2× its natural
  share, so the prior is corrected, not replaced. Evaluation is always on the natural
  distribution.
- Report per-regime barrier BA/log loss/ECE, momentum accuracy, quantile coverage; the audit's
  slice pattern (bull 0.358, high-vol 0.364) is the reference.
- Cost: 3 runs × 13 min ≈ 40 min.

### 6.3 T6 — Candlestick pattern learning

- The 103-pattern/16-structure research dataset stays an **analysis and weighting** source.
  Adding pattern-context inputs would change the 12-feature contract, so it is **not** done;
  this is an explicit scope decision, not an oversight.
- Use it for: per-tag `pos_weight` (L6), context-conditional sample weights (pattern × volume
  × trend × S/R bucket from the pattern dataset), and an honest report of which conditional
  contexts actually separate outcomes (the registry's hit rates are near 50 % with large n —
  treat as hypothesis generation).
- Cost: analysis 20 min; 2 runs × 13 min.

### 6.4 T7 — Prediction-error intelligence

- New module `src/patron/training/error_intelligence.py` consuming the runtime ledger
  (`data/runtime/patron.db`) + matured evaluations; never mutates a forecast.
- Per matured horizon: absolute/relative error, interval miss, barrier error type
  (tp↔timeout, sl↔timeout), momentum confusion, per-step/per-head/per-regime aggregates,
  calibration by confidence bucket, repeated-failure signatures.
- Output: `reports/live/error_intelligence.json` + a rolling summary that T8 can trigger on.
- Tests: fixed synthetic ledger with known errors; assert aggregation, ordering, immutability.

### 6.5 T8 — Advanced continual training

- Extend `runtime/learning.py`: dataset versioning (hash + row count + matured-only flag),
  hardness/regime weights applied to the recent slice, candidate training through T9's runner
  with the validated config, one job at a time, cooldown, champion untouched.
- Keep the existing guardrails: matured labels only, no self-training, chronological order,
  dedupe by candle, append-only evaluations.
- Tests: dataset version bumps, duplicate prevention, cooldown, inference independence.

### 6.6 T9 — Experiment runner

- `scripts/run_experiment.py`: config file → run directory; records experiment ID, model
  version, checkpoint sha256, dataset sha256, feature version, optimizer, LR, scheduler,
  batch, loss config, epochs, seed, stride, wall-clock, thread count, CPU model, val metrics,
  walk-forward metrics; resumable from `last.pt`; refuses to start if another run holds the
  lock (single-job rule).
- Registry: `experiments/registry.jsonl` (append-only).
- Tests: resume restores optimizer/epoch; duplicate run rejected; registry row complete.

### 6.7 T10 — Advanced evaluation

- Add: Brier (already computed per pattern tag; add for barrier/momentum), per-horizon and
  per-regime tables, bootstrap CIs over time blocks (block bootstrap, 1,000 reps), seed
  dispersion, coverage-vs-nominal plot data, walk-forward with **retraining** per fold.
- Explicit anti-gaming: pinball reported together with median MAE and coverage; accuracy
  reported at both the trained operating point and the validation-chosen rule.

### 6.8 T11 — Champion/challenger governance

- Extend `runtime/governance.evaluate_gates` with the §7 gates: calibration, regime floor,
  stability across seeds, walk-forward, and a rollback dry run.
- Candidates are compared against the champion record in the registry, never by training loss.
- Rejections persist reasons and artifacts.

### 6.9 T12 — Final integration

- Integrate only the validated training configuration; keep 272,618 params (assert in test);
  re-run inference contract tests; update `config/` (new experiment config, champion config
  only after promotion), README, `plan/memory.md`, roadmap, and the runtime's candidate
  training defaults.

## 7. Pre-registered promotion gates (fixed before any experiment result)

These are written now so they cannot be tuned after seeing outcomes. Changing them later
requires a written justification and invalidates the affected claim.

### 7.1 Integrity
1. Dataset sha256 unchanged (`f0d486…b4421`), feature version unchanged, split counts unchanged.
2. `tests/test_leakage_protocol.py` and `tests/test_{model_losses,dataset}.py` pass.
3. Candidate params == 272,618; input `(B,96,12)`; output schema valid; inference latency ≤ 1.2× v2.

### 7.2 Head gates (validation, champion reference in §1)
4. Barrier: macro-F1 ≥ **0.3885** and balanced accuracy ≥ **0.4091** and log loss ≤ **1.0636**
   and ECE ≤ **0.05**.
5. Momentum: (accuracy ≥ **0.2486** or macro-F1 ≥ **0.2454**) and log loss ≤ **1.5834**.
6. Quantile: pinball ≤ **0.000952** and coverage ∈ **[0.78, 0.86]** and median MAE ≤ **0.00250**.
7. Pattern: mAP ≥ **0.0952**.
8. No-regression floors: barrier BA ≥ **0.3991**, quantile pinball ≤ **0.001022**, pattern mAP
   ≥ **0.0802**.

### 7.3 Composite selection metric (used for checkpointing, T2-E6)
`score = 0.40·(barrier macro-F1) + 0.20·(1 − barrier log loss/ln3) + 0.15·(momentum macro-F1)
+ 0.15·(1 − pinball/0.001279) + 0.10·(pattern mAP) − 0.05·max(0, ECE_barrier − 0.05)`,
where 0.001279 is the constant-zero pinball on validation (fixed constant, not recomputed per
run). Monotone in every head, anchored to fixed references, never on test. v2 scores ≈ 0.234;
a candidate must beat it *and* clear §7.2, so the composite alone can never promote.

### 7.4 Stability and robustness
9. 3 seeds: mean − 1σ still passes gate 4; at least 2/3 seeds pass individually.
10. Walk-forward with retraining, 3 folds: mean barrier macro-F1 ≥ champion fold mean − 0.005,
    no fold worse than − 0.02.
11. Regime: no slice with n ≥ 500 drops barrier BA by > 0.03; at least one of bull/bear improves.
12. Rollback dry run succeeds before promotion.

## 8. Compute budget

| Work | Estimate |
|---|---|
| T1 diagnostics (done) | 2 min |
| Epoch (stride 2, batch 128) | ~100 s train + ~15 s val |
| T2 full series (~14 runs) | ~3 h |
| T3 grid (10 runs × 2 seeds) + confirmation | ~4.5 h |
| T4 + T5 | ~2 h |
| T6 | ~1 h |
| T7/T8/T9 implementation + tests | no training |
| Final 3-seed 15-epoch candidate + walk-forward 3 folds | ~2.5 h |
| **Total** | **~13 h CPU across several sessions** — no cloud, no concurrent runs |

## 9. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Validation overfitting from many experiments | fixed gate set (§7), ≤ 3 variants carried forward, single final test evaluation |
| Seed noise (~0.0039 BA) read as improvement | 3 seeds for any claim; "within noise" reported explicitly |
| Quantile gains from widening intervals | coverage window + median-MAE gate |
| Class-weight change merely moves the operating point | report accuracy and BA at both rules; gates require both |
| Hard-example weighting memorises rare events | caps `w_max ≤ 5`, ≤ 20 % mass, reuse counters, control run |
| Regime weighting distorts the prior | 2× share cap, natural-distribution evaluation |
| CPU contention / timeouts | one run at a time, 6 threads, resumable checkpoints (T9) |
| Runtime regression from training changes | inference contract tests + 272,618-param assertion + rollback gate |
| Nonstationarity (2021–2026 regimes) | walk-forward retraining, per-regime reporting |

## 10. Definition of done (whole upgrade)

A candidate is promoted only if it passes §7 on validation, stability, walk-forward and
regime gates, then is evaluated once on test with a reported block-bootstrap CI, and is
registered with its dataset/config hashes. Otherwise the champion stays, the rejection is
recorded, and no improvement is claimed. The final report must state, per head, the metric,
the reference, the delta, the seed count and the split — or state that no improvement was
demonstrated.

## 11. Exact next command

The first T2 step needs no new code beyond the train-only stride added in T1
(E0 control, 6 epochs, seed 42, full-size validation):

```bash
./.venv/Scripts/python.exe scripts/train.py --run-name e0_control_s42 --epochs 6 --train-stride 2
```

Then, before the rest of the E-series, T9's runner is required for comparable records:

```bash
./.venv/Scripts/python.exe -m pytest tests/test_leakage_protocol.py tests/test_model_losses.py
```
