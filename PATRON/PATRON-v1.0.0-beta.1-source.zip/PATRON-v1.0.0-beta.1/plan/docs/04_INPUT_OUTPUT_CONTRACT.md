# 4. Input / Output Contract

## 4.1 Inference input
PATRON receives a chronological batch of 96 closed candles, with enough warm-up history to calculate indicators. The API may accept raw OHLCV and run the feature builder internally; the model core itself accepts the normalized tensor.

### Raw candle object
Required: `timestamp`, `open`, `high`, `low`, `close`, `volume`.
Timestamp: ISO-8601 UTC. Numeric values must be finite. Candles oldest to newest.

### Model tensor
- Shape: `[1, 96, 12]` for one forecast.
- dtype: float32.
- feature order exactly as documented.
- normalized with the training scaler.
- No missing values.

## 4.2 Output
Output includes:
- status and timestamps
- model and feature versions
- pattern tags with scores
- barrier outcome probabilities
- future 6-step High/Low/Close quantile ranges
- momentum class probabilities and selected class
- quality/validation metadata

The model does not return a buy/sell order, leverage, position size or guaranteed target. A downstream deterministic risk layer is a separate future project and is not included in this model package.

## 4.3 Example interpretation
If `tp_first=0.55`, it means the model estimates 55% probability that the defined upper ATR barrier is touched before the lower barrier within the 6-candle horizon, under the label rules. It does not mean a 55% guaranteed profitable trade. Probabilities must be calibrated and tested.

Quantiles are conditional distribution estimates, not exact future prices. q10–q90 is an uncertainty band, not a guarantee that price stays inside it.
