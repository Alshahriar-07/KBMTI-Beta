# 5. Training and Evaluation Plan

## 5.1 Baselines first
Before neural training, create:
- Majority-class / empirical probability baseline
- Buy-and-hold reference (for strategy context only)
- Momentum rule baseline
- Mean-reversion baseline
- LightGBM classifier/regressor using engineered features

PATRON must be compared on identical chronological folds and labels.

## 5.2 Dataset split
Suggested starting split:
- Earliest ~70%: development/training period
- Next ~15%: validation / model selection / calibration
- Latest ~15%: final untouched test (aim for roughly last 6 months where data length allows)

Use expanding or rolling walk-forward folds inside development data. Apply purge/embargo of at least forecast horizon (6 bars) around boundaries. Do not randomly shuffle time-series samples across train and test.

## 5.3 Metrics
Barrier classification:
- Macro F1, per-class precision/recall
- Log loss, Brier score
- Confusion matrix
- ECE / reliability diagram

Range forecasts:
- Pinball loss by quantile and horizon
- Coverage of q10–q90 interval
- MAE for q50
- Separate High, Low and Close errors

Momentum:
- Macro F1, balanced accuracy, confusion matrix

Pattern tags:
- Per-tag precision/recall/F1 and PR-AUC
- Report rare-label performance separately

Decision usefulness:
- Cost-aware simulated outcome with fees and slippage
- Net return, max drawdown, turnover, trade count, profit factor, expectancy
- Compare against simple baseline
- Include no-trade / abstention analysis if confidence is poor

## 5.4 Backtest execution assumptions
Use next-candle execution, not same-candle hindsight. Include exchange fees and conservative slippage. Document funding only if a futures instrument is later selected. No look-ahead in signal execution. Report gross and net results separately.

## 5.5 Training reproducibility
Each run stores:
- git commit / code version
- config snapshot
- dataset manifest and checksum
- feature schema and scaler version
- random seed
- exact parameter count
- epoch history
- best checkpoint
- validation metrics
- hardware/runtime metadata

Suggested experiment tracking: MLflow locally or structured JSONL logs initially.

## 5.6 Go / no-go gates
G0 — Data gate:
- no unexplained duplicates, invalid OHLC, or silent missing-candle repairs
- feature and label tests pass

G1 — Baseline gate:
- baseline report exists; metrics reproducible

G2 — Neural model gate:
- PATRON improves relevant out-of-sample metrics over baseline across multiple walk-forward folds
- no evidence of leakage
- probability calibration acceptable
- net-of-cost result reported honestly

G3 — Robustness gate:
- stable across seeds and market regimes
- final holdout evaluated once
- paper simulation only after approval; this plan does not enable live orders

If G2 fails, do not add complexity or claim edge. Revisit labels/features or pivot to range/volatility forecasting.

## 5.7 Hardware plan
Development target is user's Windows PC (i5-9400F, 16GB RAM, RX 580 8GB) for data preparation and small experiments. PyTorch CUDA acceleration is NVIDIA-specific; AMD GPU support on Windows is not assumed. Start CPU-compatible, small batch training. If training is too slow, use a supported cloud GPU (e.g. Colab/Kaggle) and keep data/config reproducible. Do not assume RX 580 will be used by PyTorch as CUDA.
