# 3. Data, Features and Labels

## 3.1 Data source
Primary market: BTC/USDT spot OHLCV from one selected exchange. Binance public historical klines may be used if exchange selection is confirmed; keep exchange name and market type in metadata. Do not mix spot and perpetual futures without a separate feature/data version.

Recommended history: target 5 years of 15m candles, subject to source availability and quality. Download 1h and 4h candles for context features; align them using only the last fully closed higher-timeframe candle available at each 15m timestamp.

Storage:
- Raw: Parquet, immutable partitions by symbol/timeframe/year-month.
- Clean: Parquet.
- Feature/label dataset: Parquet.
- Metadata: JSON manifest with source, download time, row count, schema and checksum.

## 3.2 Required raw columns
`timestamp_open, open, high, low, close, volume, timestamp_close, quote_volume, trade_count` where available.
Keep raw exchange response separately; normalized canonical table must have UTC timestamps and float numeric columns.

## 3.3 Data validation
- Strict ascending timestamps; no duplicates.
- Expected 15m interval; identify missing intervals.
- `high >= max(open, close, low)` and `low <= min(open, close, high)`.
- Positive prices; nonnegative volume.
- NaN/Inf rejected or explicitly repaired with logged rule; never silently fill arbitrary market values.
- Closed candles only.
- Check data-source overlap and suspicious jumps.
- Record missing candles; do not fabricate OHLC without a documented policy.

## 3.4 Twelve model features
Feature order is fixed and stored in `feature_schema.json`:
1. `open_rel`: open / previous close - 1
2. `high_rel`: high / previous close - 1
3. `low_rel`: low / previous close - 1
4. `close_rel`: close / previous close - 1
5. `volume_log_rel`: log1p(volume) relative to rolling 96-candle volume baseline
6. `body_to_range`: (close-open)/(high-low+epsilon)
7. `atr14_pct`: ATR(14)/close
8. `rsi14_scaled`: RSI(14) mapped from [0,100] to [-1,1]
9. `ema9_gap`: close/EMA9 - 1
10. `ema21_gap`: close/EMA21 - 1
11. `volume_spike`: volume / rolling median(volume, 20)
12. `htf_trend`: normalized 1h/4h trend context computed from fully closed higher-timeframe candles

All rolling indicators must be causal. Warm-up rows without valid indicators are excluded. Fit normalization/scaling parameters on training data only. Use robust scaling or clipped z-score; persist exact scaler.

## 3.5 Pattern annotation
Pattern tags are auxiliary labels. Implement transparent candle-geometry rules with configurable thresholds and unit tests. Multi-candle patterns must use only completed candles. A pattern detector may output multiple tags. Do not treat the heuristic label as proof that the pattern predicts price.

## 3.6 Prediction labels
### Triple barrier
At each sample timestamp:
- Reference price: last close at input end.
- Volatility scale: ATR(14) at input end.
- Upper barrier: reference + `TP_ATR_MULTIPLIER × ATR`.
- Lower barrier: reference - `SL_ATR_MULTIPLIER × ATR`.
- Examine next 6 closed candles.
- First barrier hit determines TP-first or SL-first.
- Neither hit by end of horizon → timeout.
- If both barriers are inside the same candle's range, intrabar order is unknown. Mark ambiguous and exclude from primary barrier loss, or use conservative SL-first as a separately reported sensitivity analysis.

Initial multipliers: TP 1.5 ATR, SL 1.0 ATR. These are starting experiment values and must be tested; not claims of optimality.

### Range targets
For each of next 6 candles, calculate High/Low/Close relative to reference close. Store target array `[6,3]`. Quantile head learns q10/q50/q90 for each element.

### Momentum class
Calculate future 6-candle close return and normalize by ATR/reference price. Initial boundaries:
- Strong Bullish: normalized return ≥ +1.0
- Bullish: +0.35 to < +1.0
- Sideways: -0.35 to +0.35
- Bearish: -1.0 to < -0.35
- Strong Bearish: ≤ -1.0
Boundaries are initial hypotheses; tune only using training/validation.

## 3.7 Leakage prevention
- Input window ends at time `t`; targets begin strictly after `t`.
- Never include current unclosed candle.
- Higher-timeframe feature must use the last fully closed 1h/4h candle, not a candle that closes later.
- Split by time before fitting scalers, thresholds, feature selection or calibration.
- Purge samples whose target horizons overlap split boundaries; add embargo at least 6 bars.
- Unit tests should mutate future candles and prove features at `t` do not change.
