# 2. Model Specification

## 2.1 Input tensor
- Batch: `B`
- Sequence length: `T = 96`
- Feature count: `F = 12`
- Tensor: `X ∈ float32[B, 96, 12]`
- Input order: oldest → newest
- সব 96 candle অবশ্যই closed হতে হবে।

## 2.2 Proposed network
`Input [B,96,12]`
→ `LayerNorm(12)`
→ `1D-CNN residual feature extractor`
→ `Bi-LSTM temporal encoder`
→ `Self-Attention`
→ `Attention pooling / context vector`
→ parallel output heads.

### Initial layer configuration
1. Input projection: 12 → 32 channels.
2. CNN block A: Conv1D(32→32, kernel=3, padding=1), GELU, Dropout(0.10).
3. CNN block B: Conv1D(32→64, kernel=5, padding=2), GELU, Dropout(0.10).
4. CNN block C: Conv1D(64→64, kernel=7, padding=3), GELU; residual projection as needed.
5. Bi-LSTM: input 64, hidden size 64 per direction, 1 layer, batch_first=True, dropout disabled inside single-layer LSTM.
6. Attention: 4 heads, model dimension 128, batch_first=True.
7. Feed-forward: 128 → 128 → 64, GELU, dropout 0.15.
8. Attention pooling: learned query/weighted pooling over the 96 encoded steps.
9. Shared representation: 64 dimensions.

Note: PyTorch Conv1D input layout is `[B, channels, T]`; convert back to `[B,T,C]` before LSTM/attention.

## 2.3 Output heads
### Head A — Pattern tags (auxiliary)
Multi-label sigmoid head for 12 pattern families:
- Doji
- Hammer
- Inverted Hammer
- Hanging Man
- Shooting Star
- Bullish Engulfing
- Bearish Engulfing
- Piercing Line
- Dark Cloud Cover
- Morning Star
- Evening Star
- Three-candle continuation/reversal

Output: `pattern_scores[12]` in `[0,1]`.
These tags are auxiliary supervision only. Heuristic labels are noisy; use them to help representation, not as unquestionable ground truth. Add `unknown/other` handling in reporting if no score is high enough.

### Head B — Triple-barrier outcome
3 logits → softmax:
- `tp_first`
- `sl_first`
- `timeout`

The labels are based on whether the upper barrier, lower barrier, or neither is hit within the next 6 candles. If both barriers are touched inside the same OHLC candle and intrabar ordering is unknowable, label as ambiguous and exclude or apply a documented conservative rule. Never guess the order.

### Head C — Forward range quantiles
Predict q10, q50, q90 for each of:
- future High
- future Low
- future Close

For all 6 future steps:
shape = `[B, 6, 3 fields, 3 quantiles]` = `[B,6,3,3]` = 54 scalar outputs.
Targets are relative to last observed close (percentage/log-return space), not absolute BTC price. Convert back to price at inference.

Quantile order must satisfy `q10 ≤ q50 ≤ q90`; use a non-crossing parameterization or a crossing penalty / post-validation. Quantile loss: pinball loss.

### Head D — Momentum class (auxiliary)
5 logits → softmax:
1. Strong Bullish
2. Bullish
3. Sideways
4. Bearish
5. Strong Bearish

Labels must be derived from future 6-candle movement using a documented volatility-normalized threshold. Thresholds are tunable and must be selected on training/validation only.

## 2.4 Loss function
Initial weighted multi-task loss:
`L = 1.0*L_barrier + 0.5*L_quantile + 0.2*L_momentum + 0.15*L_pattern`

- `L_barrier`: weighted cross entropy (class weights estimated from training set only).
- `L_quantile`: mean pinball loss over 6×3×3 targets.
- `L_momentum`: cross entropy.
- `L_pattern`: masked binary cross entropy; only labels with reliable annotation included.
Weights are starting values, not sacred constants. Tune with validation folds and log every experiment.

## 2.5 Parameter budget
- Target initial model size: approximately 0.2M–1.0M trainable parameters.
- Exact count must be printed by the implementation and recorded in each experiment.
- If the chosen exact dimensions exceed 1M, reduce CNN channels / LSTM hidden size before expanding.
- Do not scale model size before proving data quality and baseline performance.

## 2.6 Regularization and optimization defaults
- Optimizer: AdamW
- Initial learning rate: `3e-4`
- Weight decay: `1e-4`
- Batch size: `128` (reduce to 32/64 if memory limits)
- Epoch cap: `100`
- Early stopping patience: `12` validation epochs
- Gradient clipping: `1.0`
- Dropout: `0.10–0.20`
- Scheduler: ReduceLROnPlateau or cosine schedule with warmup; choose one and log it.
- Seed: `42` for reproducibility; run multiple seeds for final robustness.
- Mixed precision: optional CUDA AMP only when supported and stable.
- Save best checkpoint by validation objective, not training loss.

## 2.7 Calibration
Fit temperature scaling (first choice) or isotonic calibration on validation predictions only. Never fit calibration on final test. Report Brier score, log loss, reliability diagram and expected calibration error (ECE).

## 2.8 Inference constraints
- Model is deterministic in eval mode.
- Dropout off during inference.
- Same feature code, scaler, feature order and config used in training.
- Reject wrong tensor shape, stale candle data, NaN/Inf, and non-monotonic timestamps.
