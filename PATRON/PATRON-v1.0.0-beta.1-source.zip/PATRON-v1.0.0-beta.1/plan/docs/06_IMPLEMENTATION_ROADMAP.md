# 6. Implementation Roadmap

## Phase 0 — Project foundation
Deliverables:
- Python project and virtual environment
- configuration management
- structured logging
- data/schema versioning
- reproducible run command

Acceptance:
- fresh environment installs successfully
- config validation works
- run metadata is saved

## Phase 1 — Historical data pipeline
Tasks:
- select exchange and market type
- download 5-year target 15m history
- obtain 1h/4h context data
- normalize timestamps and schema
- validate gaps, duplicates, NaN/Inf, OHLC constraints
- write raw and clean Parquet partitions

Acceptance:
- data manifest and quality report produced
- no unexplained corruption
- rerun does not duplicate rows

## Phase 2 — Features and labels
Tasks:
- implement exact 12 features in fixed order
- implement 96-candle window builder
- implement pattern tag annotations
- implement triple barrier, range and momentum labels
- write look-ahead/leakage tests

Acceptance:
- feature schema versioned
- train-only scaler saved
- unit tests prove future candles cannot alter past features

## Phase 3 — Baselines
Tasks:
- train majority, momentum, mean-reversion baselines
- train LightGBM
- run chronological validation
- create baseline report

Acceptance:
- baseline metrics and cost-aware report exist

## Phase 4 — PATRON neural model
Tasks:
- implement CNN + Bi-LSTM + Attention
- implement 4 heads and multi-task loss
- count parameters
- train with early stopping
- save best checkpoint and experiment metadata

Acceptance:
- training reproducible
- output shapes and finite values verified
- validation report complete

## Phase 5 — Calibration and final evaluation
Tasks:
- calibrate barrier probabilities on validation
- evaluate walk-forward folds
- evaluate final untouched holdout once
- compare against baseline and report uncertainty

Acceptance:
- G2/G3 decision memo completed
- no live trading by default

## Phase 6 — Inference package
Tasks:
- load checkpoint, scaler and config
- accept raw 96-candle input or normalized tensor
- validate inputs
- return versioned JSON output
- add CLI command and Python API

Acceptance:
- same input + same model version yields same output in eval mode
- invalid input returns clear validation error
- sample inference end-to-end works

## Suggested timeline
One developer working part-time:
- Week 1: foundation + source selection
- Weeks 2–3: data pipeline
- Weeks 4–5: features, labels, leakage tests
- Weeks 6–7: baselines
- Weeks 8–10: neural model
- Weeks 11–12: calibration, walk-forward and inference packaging

Timeline is an estimate; data quality and baseline results may change it.
