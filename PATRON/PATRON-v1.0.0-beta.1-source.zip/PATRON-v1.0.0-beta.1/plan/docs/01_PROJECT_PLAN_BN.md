# 1. Project Plan — PATRON

## 1.1 পরিচিতি
**Project name:** PATRON  
**Full name:** Pattern Recognition & Outcome Network  
**Model type:** Supervised deep-learning model for time-series / OHLCV data  
**Primary asset:** BTC/USDT  
**Primary timeframe:** 15m  
**Context:** আগের 96টি সম্পূর্ণ candle  
**Forecast:** পরবর্তী 6টি candle (মোট 90 মিনিট)

PATRON-এর লক্ষ্য কোনো নির্দিষ্ট candlestick নাম মুখস্থ করা নয়। একই Hammer/Engulfing pattern uptrend, downtrend, range, high-volume বা low-volume অবস্থায় আলাদা অর্থ বহন করতে পারে। তাই model candle shape-এর পাশাপাশি temporal context, volatility, volume এবং trend শিখবে।

## 1.2 Main objectives
1. 96টি closed candle থেকে market context ও candle formations শনাক্ত করা।
2. প্রাসঙ্গিক candlestick pattern-এর সম্ভাব্য tag/score দেওয়া।
3. পরবর্তী 6 candle-এর মধ্যে ATR-scaled Take-Profit আগে, Stop-Loss আগে, নাকি timeout হবে—তার probability অনুমান করা।
4. পরবর্তী 6 candle-এর প্রতিটি ধাপের High, Low ও Close-এর q10/q50/q90 range estimate করা।
5. Momentum-কে পাঁচটি class-এ শ্রেণিবদ্ধ করা।
6. Calibrated probability, uncertainty ও data-quality status দেওয়া।
7. Historical walk-forward test-এ simple baseline-এর চেয়ে ভালো হয় কি না তা প্রমাণ করা।

## 1.3 Non-goals / এখন যা বানানো হবে না
- LLM, Ollama বা natural-language reasoning
- News, macro calendar, social sentiment
- AI agent, tool calling বা autonomous workflow
- Telegram bot, web dashboard
- Exchange order placement বা live auto-trading
- Model নিজে নিজে approval ছাড়া production weights replace করবে না

## 1.4 User journey / end-to-end flow
`Exchange historical data → Raw OHLCV → Validation → Feature Builder → 96×12 Tensor → PATRON → Prediction JSON → Evaluation/Report`

Inference-এ:
1. সর্বশেষ 96টি **closed** 15m candle নিতে হবে।
2. timestamp, order, duplicate, missing candle, NaN/Inf ও OHLC consistency validate করতে হবে।
3. একই version-এর feature pipeline দিয়ে 12টি feature তৈরি করতে হবে।
4. saved scaler/normalizer প্রয়োগ করতে হবে।
5. `float32` tensor `[1, 96, 12]` model-এ দিতে হবে।
6. model probabilities, range quantiles, momentum ও pattern tags ফেরত দেবে।
7. data invalid বা model output invalid হলে forecast নয়—`NO_OUTPUT` status দিতে হবে।

## 1.5 Development principles
- Closed candles only; forming candle ব্যবহার করা যাবে না।
- Train/validation/test chronological হবে; random shuffle split নয়।
- Scaler শুধু training partition-এ fit হবে।
- Feature বা label তৈরির সময় future data ব্যবহার করা যাবে না।
- Probability-কে calibration ছাড়া certainty হিসেবে দেখানো যাবে না।
- সব forecast-এ model version, feature version, timestamp ও input hash log হবে।
- Backtest-এ fee, slippage এবং next-candle execution assumption অন্তর্ভুক্ত করতে হবে।

## 1.6 Success definition
PATRON সফল বলা যাবে কেবল যদি:
- Data pipeline deterministic ও reproducible হয়।
- Leakage tests pass করে।
- Walk-forward out-of-sample ফল simple baseline/LightGBM-এর তুলনায় উন্নত বা অন্তত নির্দিষ্ট use-case-এ measurable value দেখায়।
- Probability calibration গ্রহণযোগ্য হয়।
- Fees/slippage-এর পরে performance টিকে থাকে।
- Test period একবার final holdout হিসেবে ব্যবহার হয়; বারবার tune করার জন্য নয়।

কোনো model যদি baseline beat না করে, সেটি ব্যর্থ ফল হিসেবে নথিভুক্ত হবে—কৃত্রিমভাবে success দাবি করা হবে না।
