# Decisions and Assumptions

## Fixed for PATRON v1
- Project/model name: PATRON
- Market: BTC/USDT
- Main timeframe: 15m
- Context window: 96 closed candles
- Forecast horizon: next 6 candles / 90 minutes
- Input: 96 × 12 features
- Core architecture: 1D-CNN → Bi-LSTM → Self-Attention
- Main outputs: triple-barrier probabilities, range quantiles, momentum class
- Pattern tags: auxiliary multi-label head
- Framework: PyTorch
- Data: Parquet
- LLM/news/agent/live execution: excluded

## Initial defaults requiring experiments
- TP barrier: 1.5 × ATR(14)
- SL barrier: 1.0 × ATR(14)
- Momentum thresholds: ±0.35 and ±1.0 ATR-normalized units
- AdamW learning rate: 3e-4
- Weight decay: 1e-4
- Batch size: 128
- Epoch cap: 100
- Early stopping patience: 12
- Loss weights: barrier 1.0, quantile 0.5, momentum 0.2, pattern 0.15
- CNN channels: 32/64
- Bi-LSTM hidden: 64 per direction
- Attention: 4 heads
- Dropout: 0.10–0.20

These are starting values, not optimized truths. Tune using training/validation only.

## Decisions to confirm before implementation
1. Exchange/data source: Binance spot BTC/USDT is proposed, not yet locked.
2. Historical depth: target 5 years if clean data is available.
3. Storage location and available disk space.
4. Whether pattern labels should include all 12 proposed families or begin with a smaller reliable subset.
5. Whether the range head should predict each of six future candles (chosen here) or one aggregate 90-minute range. This plan chooses per-candle forecasts for richer output.

## Source alignment
This plan is based on the user's BTCPatternForecaster v2.0 pre-production blueprint for the 96×12 input, CNN + Bi-LSTM + Attention architecture, triple-barrier / quantile / momentum heads, calibration, Parquet data, walk-forward validation and baseline-first approach. The PATRON-specific pattern-tag head, exact initial hyperparameters, feature formulas and detailed JSON contract are implementation refinements proposed in this plan.
